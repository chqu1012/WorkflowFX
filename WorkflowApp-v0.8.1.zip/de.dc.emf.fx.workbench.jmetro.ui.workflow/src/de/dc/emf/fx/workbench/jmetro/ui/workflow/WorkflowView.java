package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

import com.google.inject.Inject;

import de.dc.emf.fx.workbench.jmetro.core.di.EmfFXPlatform;
import de.dc.emf.fx.workbench.jmetro.core.event.IEventBroker;
import de.dc.emf.fx.workbench.jmetro.core.service.ISelectionService;
import de.dc.emf.fx.workbench.jmetro.ui.EmfView;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class WorkflowView extends EmfView implements ChangeListener<TreeItem<Object>>{

	@Inject ISelectionService selectionService;
	@Inject IEventBroker eventBroker;
	
	private VBox vbox;
	private WorkflowRenderer renderer;
	
	public WorkflowView() {
		super("Workflows");
		
		EmfFXPlatform.inject(this);
		
		selectionService.addListener(this);
		eventBroker.register(this);

		renderer = new WorkflowRenderer();
		
		AnchorPane content = new AnchorPane();
		content.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setFitToWidth(true);
		vbox = new VBox(10d);
		vbox.setPadding(new Insets(5));
		vbox.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		scrollPane.setContent(vbox);
		AnchorPane.setBottomAnchor(scrollPane, 0d);
		AnchorPane.setTopAnchor(scrollPane, 0d);
		AnchorPane.setLeftAnchor(scrollPane, 0d);
		AnchorPane.setRightAnchor(scrollPane, 0d);
		
		content.getChildren().add(scrollPane);
		
		setContent(content);
	}
	
	@Override
	public void changed(ObservableValue<? extends TreeItem<Object>> observable, TreeItem<Object> oldValue,
			TreeItem<Object> newValue) {
		if (newValue != null) {
			Object value = newValue.getValue();
			vbox.getChildren().clear();
			Node node = renderer.doSwitch((EObject) value);
			if (node != null) {
				vbox.getChildren().add(node);
			}
		}
	}

}
