package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.sc.Service;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.TableViewUtil;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.WinScUtil;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ServiceCheckControl extends VBox{

	private WinScUtil util = new WinScUtil();

	private ObservableList<Service> masterData = FXCollections.observableArrayList();
	private FilteredList<Service> filteredData = new FilteredList<Service>(masterData);
	private SortedList<Service> sortedData = new SortedList<>(filteredData);

	public ServiceCheckControl(ServiceCheck object) {
		TextField textSearch = new TextField();
		textSearch.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (newValue!=null) {
					filteredData.setPredicate(p->{
						boolean isEmpty = StringUtils.isEmpty(newValue);
						String value = newValue.toLowerCase();
						boolean containsName = p.getName().toLowerCase().contains(value);
						boolean containsStatus = p.getStatus().name().toLowerCase().contains(value);
						boolean containsType = p.getType().toLowerCase().contains(value);
						String description = p.getDescription()==null?"":p.getDescription();
						boolean containsDescription = description.toLowerCase().contains(value);
						return isEmpty || containsName || containsStatus || containsType || containsDescription;
					});
				}
			}
		});
		TableView<Service> tableView = new TableView<>();
		tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		
		ContextMenu contextMenu = new ContextMenu();
		MenuItem menuItemExportHtml = new MenuItem("Export to Html");
		menuItemExportHtml.setOnAction(e->{
			FileChooser fc = new FileChooser();
			fc.setInitialFileName("services.html");
			File file = fc.showSaveDialog(new Stage());
			if (file != null) {
				try {
					TableViewUtil.exportToHtml(tableView, file);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		contextMenu.getItems().add(menuItemExportHtml);
		MenuItem menuItemExportExcel = new MenuItem("Export to Excel");
		contextMenu.getItems().add(menuItemExportExcel);
		tableView.setContextMenu(contextMenu);
		
		sortedData.comparatorProperty().bind(tableView.comparatorProperty());
		tableView.setItems(sortedData);
		
		String[] columnNames = {"name", "type", "description", "server", "status"};
		for (String name : columnNames ) {
			TableColumn<Service, Object> col = new TableColumn<>(name);
			col.setCellValueFactory(new PropertyValueFactory<>(name));
			tableView.getColumns().add(col);
			if (name.equals("status")) {
//				col.setCellFactory(e->new TableCell<Service, Object>(){
//					protected void updateItem(Object item, boolean empty) {
//						super.updateItem(item, empty);
//						if (item == null || empty) {
//							setStyle(null);
//						}else {
//							ServiceStatus value = (ServiceStatus) item;
//							if (value.equals(ServiceStatus.RUNNING)) {
//								setStyle("-fx-text-fill: green;");
//							}else if (value.equals(ServiceStatus.STOPPED)) {
//								setStyle("-fx-text-fill: red;");
//							}
//						}
//					};
//				});
			}
		}
		
		tableView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		VBox.setVgrow(tableView, Priority.ALWAYS);
		
		getChildren().add(textSearch);
		getChildren().add(tableView);
	
		masterData.addAll(util.findAll());
		
		setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		setVgrow(tableView, Priority.ALWAYS);
	}
}