package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import java.io.File;

import org.eclipse.emf.common.util.EList;

import de.dc.emf.fx.workbench.jmetro.core.di.EmfFXPlatform;
import de.dc.emf.fx.workbench.jmetro.core.event.EventTopic;
import de.dc.emf.fx.workbench.jmetro.core.event.IEventBroker;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.CsvTableView;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.DialogRenderer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.MkdirControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.QueryControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.RemoteDesktopControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.ServiceCheckControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.control.SourceDestinationControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.OperationSwitch;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.ReplacementSwitch;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.WorkflowSwitch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class WorkflowRenderer extends WorkflowSwitch<Node> {

	private OperationSwitch operations = new OperationSwitch();
	private ReplacementSwitch replacements = new ReplacementSwitch();
	private DialogRenderer dialogControl = new DialogRenderer();
	
	public WorkflowRenderer() {
		EmfFXPlatform.inject(this);
	}
	
	@Override
	public Node caseCsvTableParser(CsvTableParser object) {
		return new CsvTableView(object);
	}
	
	@Override
	public Node caseLineChart(LineChart object) {
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel(object.getXTitle());
        yAxis.setLabel(object.getYTitle());
        final javafx.scene.chart.LineChart<Number,Number> lineChart = 
                new javafx.scene.chart.LineChart<Number,Number>(xAxis,yAxis);
                
        lineChart.setTitle(object.getTitle());
        lineChart.setLegendVisible(false);
        lineChart.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        XYChart.Series series = new XYChart.Series();
        for (Point p : object.getPoints()) {
        	series.getData().add(new XYChart.Data(p.getX(), p.getY()));
		}
        
        lineChart.getData().add(series);
        
        return lineChart;
	}
	
	@Override
	public Node caseExe(Exe object) {
		Label label = new Label("Exe");
		HBox parent = new HBox(label);
		parent.setAlignment(Pos.CENTER_LEFT);
		parent.setPadding(new Insets(5d));
		parent.setSpacing(5);

		String path = replacements.doSwitch(object.getPath());
		TextField text = new TextField(path);
		text.setEditable(false);
		
		HBox.setHgrow(text, Priority.ALWAYS);
		parent.getChildren().add(text);
		
		Button buttonExecute = new Button("Execute");
		buttonExecute.setOnMouseClicked(e->{
			EmfFXPlatform.getInstance(IEventBroker.class).post(EventTopic.OPEN_FILE_VIA_HOSTSERVICE, new File(text.getText()));
		});
		parent.getChildren().add(buttonExecute);
		
		return parent;
	}

	@Override
	public Node caseInputDialog(InputDialog object) {
		return dialogControl.doSwitch(object);
	}
	
	@Override
	public Node caseServiceCheck(ServiceCheck object) {
		return new ServiceCheckControl(object);
	}
	
	@Override
	public Node caseMove(Move object) {
		return new SourceDestinationControl<Copy>(object, "Move");
	}
	
	@Override
	public Node caseCopy(Copy object) {
		return new SourceDestinationControl<Copy>(object, "Copy");
	}
	
	@Override
	public Node caseZip(Zip object) {
		return new SourceDestinationControl<Copy>(object, "Zip");
	}
	
	@Override
	public Node caseMkdir(Mkdir object) {
		return new MkdirControl(object);
	}
	
	@Override
	public Node caseWorkflow(Workflow object) {
		VBox vbox = new VBox();
		EList<Operation> ops = object.getOperations();
		for (Operation operation : ops) {
			Node node = doSwitch(operation);
			if (node != null) {
				vbox.getChildren().add(node);
			}
		}
		return vbox;
	}

	@Override
	public Node caseClipboard(Clipboard object) {
		HBox hbox = createHbox("String to Clipboard:");

		TextField control = new TextField();
		control.setEditable(false);
		control.setText(object.getContent());
		HBox.setHgrow(control, Priority.ALWAYS);
		hbox.getChildren().add(control);

		ProgressBar progressBar = new ProgressBar(0);
		progressBar.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		hbox.getChildren().add(progressBar);

		Button button = new Button("Clipboard");
		hbox.getChildren().add(button);

		button.setOnAction(e -> {
			operations.doSwitch(object);
			progressBar.setProgress(100);
		});
		return hbox;
	}

	@Override
	public Node caseDBTableView(DBTableView object) {
		TabPane tab = new TabPane();
		object.getQueries().forEach(e -> {
			Tab tabItem = new Tab(e.getName());
			tabItem.setContent(doSwitch(e));
			tab.getTabs().add(tabItem);
		});
		return tab;
	}

	@Override
	public Node caseDBConsole(DBConsole object) {
		HBox hbox = createHbox("Server Console:");

		TextField labelStatus = new TextField("");
		labelStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");
		labelStatus.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		HBox.setHgrow(labelStatus, Priority.ALWAYS);
		hbox.getChildren().add(labelStatus);

		Button buttonStart = new Button("Start");
		Button buttonStop = new Button("Stop");
//		try {
//			final Server server = Server.createWebServer(new String[] { "-webPort", object.getPort() + "" });
//			buttonStart.setOnMouseClicked(e -> {
//				try {
//					server.start();
//					labelStatus.setText(server.getURL());
//					labelStatus.setStyle("-fx-background-color: green; -fx-text-fill: white;");
//					buttonStart.setDisable(true);
//					buttonStop.setDisable(false);
//				} catch (SQLException e1) {
//					e1.printStackTrace();
//				}
//			});
//			buttonStop.setOnMouseClicked(e -> {
//				labelStatus.setStyle("-fx-background-color: red;");
//				labelStatus.setText("");
//				server.stop();
//				buttonStart.setDisable(false);
//				buttonStop.setDisable(true);
//			});
//		} catch (SQLException e2) {
//			e2.printStackTrace();
//		}

		hbox.getChildren().add(buttonStart);
		hbox.getChildren().add(buttonStop);
		return hbox;
	}

	@Override
	public Node caseRemoteDesktop(RemoteDesktop object) {
		RemoteDesktopControl control = new RemoteDesktopControl(object);
		control.setOnAction(() -> {
			operations.doSwitch(object);
//			logService.info("Run remote desktop on " + object.getServer() + " by user " + object.getUser());
		});
		return control;
	}

	@Override
	public Node caseQuery(Query object) {
		return new QueryControl(object);
	}

	private HBox createHbox(String name) {
		Label label = new Label(name);
		label.setPrefWidth(120);
		HBox hbox = new HBox(label);
		hbox.setAlignment(Pos.CENTER_LEFT);
		hbox.setPadding(new Insets(5d));
		hbox.setSpacing(5);
		return hbox;
	}
}
