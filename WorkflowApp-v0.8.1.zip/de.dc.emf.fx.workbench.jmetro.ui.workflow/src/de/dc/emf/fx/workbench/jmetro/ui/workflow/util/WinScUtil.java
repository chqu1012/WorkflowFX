package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.sc.Service;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.sc.ServiceStatus;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class WinScUtil {

    private Logger log = Logger.getLogger(getClass().getName());

    public static final String SC_QUERY_FIND_ALL = "sc query type= own state= all | findstr \"SERVICE_NAME DISPLAY_NAME STATE TYPE\"";

    public static final String SC_QUERY_FIND_ALL_BY_SERVER = "sc \\\\%s query type= own state= all | findstr \"SERVICE_NAME DISPLAY_NAME STATE TYPE\"";

    public static final String SC_QUERY_FIND_BY_SERVER = "sc \\\\%s query \"%s\" | findstr \"SERVICE_NAME DISPLAY_NAME STATE TYPE\"";

    public static final String CMD_EXE = "cmd.exe";

    public static final String TYPE_OWN = "WIN32_OWN_PROCESS";

    private static final String SC_RUNNING = "RUNNING";

    private static final String SC_STOPPED = "STOPPED";

    private static final String SC_SERVICE_NAME = "SERVICE_NAME";

    private static final String SC_DISPLAY = "DISPLAY_NAME";

    private static final String SC_TYPE = "TYPE";

    private static final String SC_STATE = "STATE";

    private static final String FORMAT_COLON = ":";

    private static final String FORMAT_SPACES = "  ";

    private static final String FORMAT_BACKSPLASHES = "\\\\";

    private ObservableList<Service> masterData = FXCollections.observableArrayList();

    public Process start(String serviceName) throws IOException {
        if (serviceName.isEmpty()) {
            log.log(Level.SEVERE, String.format("Service (%s) might not be empty or null! ", serviceName));
            return null;
        }
        String[] script = { CMD_EXE, "/c", "sc", "start", serviceName };
        return Runtime.getRuntime().exec(script);
    }

    public Process start(String server, String serviceName) throws IOException {
        if (server.isEmpty() || serviceName.isEmpty()) {
            log.log(Level.SEVERE, String.format("Server (%s) or service (%s) might not be empty or null! ", server, serviceName));
            return null;
        }
        String[] script = { CMD_EXE, "/c", "sc", FORMAT_BACKSPLASHES + server, "start", serviceName };
        return Runtime.getRuntime().exec(script);
    }

    public Process start(String server, String serviceName, String user, String password) throws IOException {
        String[] script = { CMD_EXE, "/c", "sc", FORMAT_BACKSPLASHES + server, "start", serviceName, "obj= ", user,
                "password= ", password };
        return Runtime.getRuntime().exec(script);
    }

    public Process stop(String server, String serviceName, String user, String password) throws IOException {
        String[] script = { CMD_EXE, "/c", "sc", FORMAT_BACKSPLASHES + server, "stop", serviceName, "obj= ", user,
                "password= ", password };
        return Runtime.getRuntime().exec(script);
    }

    public Process stop(String server, String serviceName) throws IOException {
        if (server.isEmpty() || serviceName.isEmpty()) {
            log.log(Level.SEVERE, String.format("Server (%s) or service (%s) might not be empty or null! ", server, serviceName));
            return null;
        }
        String[] script = { CMD_EXE, "/c", "sc", FORMAT_BACKSPLASHES + server, "stop", serviceName };
        return Runtime.getRuntime().exec(script);
    }

    public Process stop(String serviceName) throws IOException {
        if (serviceName.isEmpty()) {
            log.log(Level.SEVERE, String.format("Service (%s) might not be empty or null! ", serviceName));
            return null;
        }
        String[] script = { CMD_EXE, "/c", "sc", "stop", serviceName };
        return Runtime.getRuntime().exec(script);
    }

//    public ObservableList<Service> findAllByConfig(File file) {
//        winServices.clear();
//        ObservableList<Service> result = FXCollections.observableArrayList();
//        ServerConfiguration config = serviceFile.loadData(file);
//        winServices.addAll(observableArrayList(findAllByServer(config.getName())));
//
//        winServices.forEach(winService -> {
//            if ((config.getServiceGroups().size() == 1)
//                    && config.getServiceGroups().get(0).getName().equals("General")) {
//                if (winService.getDescription().startsWith("_")) {
//                    result.addAll(winService);
//                }
//            } else {
//                config.getServiceGroups().forEach(group -> {
//                    group.getServices().forEach(service -> {
//                        if (service.getName().equals(winService.getName())) {
//                            service.setStatus(winService.getStatus());
//                            result.addAll(service);
//                        }
//                    });
//                });
//            }
//        });
//        return result;
//    }

    public ObservableList<Service> findByServiceName(String server, String serviceName) {
        String[] command = { CMD_EXE, "/c", String.format(SC_QUERY_FIND_BY_SERVER, server, serviceName) };
        return findAll(server, command);
    }

    public List<Service> findAllByServerByTypeOwn(String server) {
        return findAllByServer(server).stream()
                .filter(p -> p.getType().contains(TYPE_OWN) && p.getDescription().startsWith("_")).collect(Collectors.toList());
    }

    public List<Service> findAllByServer(String server) {
        String[] command = { CMD_EXE, "/c", String.format(SC_QUERY_FIND_ALL_BY_SERVER, server) };
        return findAll(server, command);
    }

    public ObservableList<Service> findAll() {
        String[] command = { CMD_EXE, "/c", SC_QUERY_FIND_ALL };
        return findAll(StringUtils.EMPTY, command);
    }

    private ObservableList<Service> findAll(String server, String... command) {
        masterData.clear();
        try {
            Process process = new ProcessBuilder(command).start();
            InputStream inputStream = process.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line = "";
            Service service = null;
            while ((line = bufferedReader.readLine()) != null) {
                String[] fields = line.split(FORMAT_COLON);
                if (fields.length == 2) {
                    service = parseLine(server, line, service, fields);
                }
            }
        } catch (Exception ex) {
            log.log(Level.SEVERE, "Failed on fetching services on server " + server, ex);
        }
        return masterData;
    }

    private Service parseLine(String server, String line, Service service, String[] fields) {
        if (line.startsWith(SC_SERVICE_NAME)) {
            service = new Service();
            service.setName(fields[1].trim());
            service.setServer(server);
            masterData.add(service);
        } else if (line.startsWith(SC_DISPLAY) && (service != null)) {
            service.setDescription(fields[1].trim());
        } else if (fields[0].trim().equals(SC_TYPE) && (service != null)) {
            String value = fields[1] == null ? StringUtils.EMPTY : fields[1].trim().split(FORMAT_SPACES)[1];
            service.setType(value);
        } else if (fields[0].trim().equals(SC_STATE) && (service != null)) {
            String value = fields[1] == null ? StringUtils.EMPTY : fields[1].trim().split(FORMAT_SPACES)[1];
            if (value.equals(SC_RUNNING)) {
                service.setStatus(ServiceStatus.RUNNING);
            } else if (value.equals(SC_STOPPED)) {
                service.setStatus(ServiceStatus.STOPPED);
            }
        }
        return service;
    }
}