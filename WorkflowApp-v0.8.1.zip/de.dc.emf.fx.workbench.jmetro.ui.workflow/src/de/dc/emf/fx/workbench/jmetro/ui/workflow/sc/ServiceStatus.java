package de.dc.emf.fx.workbench.jmetro.ui.workflow.sc;

public enum ServiceStatus {
	STOPPED,
	RUNNING;
}
