package de.dc.emf.fx.workbench.jmetro.ui.workflow.part;

import java.lang.reflect.Field;

import com.google.common.eventbus.Subscribe;
import com.google.inject.Inject;

import de.dc.emf.fx.workbench.jmetro.core.di.EmfFXPlatform;
import de.dc.emf.fx.workbench.jmetro.core.event.EventContext;
import de.dc.emf.fx.workbench.jmetro.core.event.EventTopic;
import de.dc.emf.fx.workbench.jmetro.core.event.IEventBroker;
import de.dc.emf.fx.workbench.jmetro.core.service.ISelectionService;
import de.dc.emf.fx.workbench.jmetro.ui.EmfView;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.LineChart;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Point;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowFactory;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class LineChartView extends EmfView{

	@Inject ISelectionService selectionService;
	@Inject IEventBroker eventBroker;
	
	private LineChart chart;
	
	public LineChartView() {
		super("LineChart Properties");
		
		EmfFXPlatform.inject(this);
		
		eventBroker.register(this);
		
		AnchorPane content = new AnchorPane();
		content.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setFitToWidth(true);
		VBox vbox = new VBox(10d);
		vbox.setPadding(new Insets(5));
		vbox.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		
		HBox hbox = new HBox(5);
		hbox.setPadding(new Insets(5));
		hbox.setAlignment(Pos.TOP_LEFT);
		
		TextField textfieldX = new TextField();
		TextField textfieldY = new TextField();
		
		hbox.getChildren().add(new Label("x:"));
		hbox.getChildren().add(textfieldX);
		hbox.getChildren().add(new Label("y:"));
		hbox.getChildren().add(textfieldY);
		
		Button buttonAdd = new Button("Add");
		buttonAdd.setOnMouseClicked(e->{
			createPoint(Double.parseDouble(textfieldX.getText()), Double.parseDouble(textfieldY.getText()));
			textfieldX.setText("");
			textfieldY.setText("");
		});
		buttonAdd.disableProperty().bind(textfieldX.textProperty().isEmpty().or(textfieldY.textProperty().isEmpty()));
		hbox.getChildren().add(buttonAdd);
		vbox.getChildren().add(new Label("Create new point:"));
		vbox.getChildren().add(hbox);
		vbox.getChildren().add(new Label("Create dummy points:"));
		
		hbox = new HBox(5);
		hbox.getChildren().add(new Label("Iterations"));
		TextField textFieldIterations = new TextField("10");
		hbox.getChildren().add(textFieldIterations);
		hbox.getChildren().add(new Label("Step"));
		TextField textFieldStep = new TextField("1");
		hbox.getChildren().add(textFieldStep);

		Button buttonDummyValues = new Button("Create Dummy Values");
		buttonDummyValues.setOnMouseClicked(e->{
			int iteration = Integer.parseInt(textFieldIterations.getText());
			int step = Integer.parseInt(textFieldStep.getText());
			for (int i = 0; i < iteration; i++) {
				int x = i+1;
				int y = (x)*step;
				createPoint(x, y);
			}
		});
		hbox.getChildren().add(buttonDummyValues);
		vbox.getChildren().add(hbox);
		
		scrollPane.setContent(vbox);
		AnchorPane.setBottomAnchor(scrollPane, 0d);
		AnchorPane.setTopAnchor(scrollPane, 0d);
		AnchorPane.setLeftAnchor(scrollPane, 0d);
		AnchorPane.setRightAnchor(scrollPane, 0d);
		
		content.getChildren().add(scrollPane);
		
		setContent(content);
	}

	private void createPoint(double x, double y) {
		if (chart!=null) {
			Point p = WorkflowFactory.eINSTANCE.createPoint();
			p.setX(x);
			p.setY(y);
			chart.getPoints().add(p);
		}
	}
	
	@Subscribe
	public void subscribeSelectLineChart(EventContext<LineChart> context) {
		if (context.match(EventTopic.EMF_MODEL_TREE_CLICK)) {
			if (context.getInput() instanceof LineChart) {
				this.chart = context.getInput();
			}
		}
	}
	
	public void setChart(LineChart chart) {
		this.chart = chart;
	}
}
