package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop;

public class RemoteDesktopRunner {

	public static void run(RemoteDesktop object) {
		String password = object.getPassword();
		run(object, password);
	}

	public static void run(RemoteDesktop object, String password) {
		StringBuilder sb = new StringBuilder();
		sb.append("cmdkey /generic:TERMSRV/%1 /user:\\%2 /password:%3\n");
		sb.append("mstsc /v:%1");

		try {
			File batchFile = new File("./StartRemoteDesktop.bat");
			FileUtils.write(batchFile, sb.toString(), StandardCharsets.UTF_8);
			String batchPath = batchFile.getAbsolutePath();
			String command = batchPath + " " + object.getServer() + " " + object.getUser() + " " + object.getPassword();
			String[] cmdArray = { "cmd.exe", "/c", command };

			Runtime.getRuntime().exec(cmdArray);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
