package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang.StringUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Item;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.TextControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowFactory;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.dialog.GenericInputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.WorkflowSwitch;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.util.Callback;
import javafx.util.StringConverter;

public class DialogRenderer extends WorkflowSwitch<Node> {

	@Override
	public Node caseInputDialog(InputDialog object) {
		GenericInputDialog dialog = new GenericInputDialog(object);
		dialog.setUserData(object);
		object.getControls().forEach(e -> {
			Node node = doSwitch(e);
			if (node != null) {
				dialog.addControl(e, node);
			}
		});
		dialog.create();
		return dialog;
	}
	
	@Override
	public Node caseListControl(ListControl object) {
		ObservableList<Item> masterData = FXCollections.observableArrayList();
		masterData.addAll(object.getItems());
		ListView<Item> control = new ListView<>(masterData);
		control.getSelectionModel().selectedItemProperty().addListener((ChangeListener<Item>) (observable, oldValue, newValue) -> {
			if (newValue!=null) {
				object.setValue(newValue.getValue());
			}
		});
		
		for (Item item : masterData) {
			if (item.getValue().equals(object.getValue())) {
				control.getSelectionModel().select(item);
			}
		}
		
		control.setCellFactory(new Callback<ListView<Item>, ListCell<Item>>() {
			@Override
			public ListCell<Item> call(ListView<Item> param) {
				return new ListCell<Item>() {
					@Override
					protected void updateItem(Item item, boolean empty) {
						super.updateItem(item, empty);
						if (empty || item == null) {
							setText(null);
						}else {
							setText(item.getValue());
						}
					}
				};
			}
		});
		return control;
	}

	@Override
	public Node caseTextControl(TextControl object) {
		TextField textField = new TextField();
		textField.setPromptText(object.getVariable());
		textField.setText(object.getValue());
		textField.textProperty().addListener((ChangeListener<String>) (observable, oldValue, newValue) -> {
			if (newValue!=null) {
				object.setValue(newValue);
			}
		});
		return textField;
	}

	@Override
	public Node caseDateControl(DateControl object) {
		DatePicker control = new DatePicker();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(object.getFormatter());
		String value = object.getValue();
		if (StringUtils.isNotEmpty(value)) {
			control.setValue(LocalDate.parse(value, dtf));
		}
		control.valueProperty().addListener((ChangeListener<LocalDate>) (observable, oldValue, newValue) -> {
			if (newValue != null) {
				object.setValue(newValue.format(dtf));
			}
		});
		return control;
	}

	@Override
	public Node caseComboControl(ComboControl object) {
		ComboBox<ComboItem> control = new ComboBox<>();
		ObservableList<ComboItem> masterData = FXCollections.observableArrayList();
		masterData.addAll(object.getItems());
		control.setItems(masterData);
		for (ComboItem comboItem : masterData) {
			if (comboItem.getValue().equals(object.getValue())) {
				control.getSelectionModel().select(comboItem);
			}
		}
		control.setCellFactory(param -> new ListCell<ComboItem>() {
			@Override
			protected void updateItem(ComboItem item, boolean empty) {
				super.updateItem(item, empty);
				if (item == null || empty) {
					setText(null);
				} else {
					setText(item.getValue());
				}
			}
		});
		control.setConverter(new StringConverter<ComboItem>() {
			@Override
			public String toString(ComboItem object) {
				String value = object.getValue();
				if (value == null) {
					return "";
				}
				return value;
			}

			@Override
			public ComboItem fromString(String string) {
				ComboItem item = WorkflowFactory.eINSTANCE.createComboItem();
				item.setValue(string);
				return item;
			}
		});
		control.getSelectionModel().selectedItemProperty()
				.addListener((ChangeListener<ComboItem>) (observable, oldValue, newValue) -> {
					if (newValue != null) {
						object.setValue(newValue.getValue());
					}
				});
		return control;
	}
}
