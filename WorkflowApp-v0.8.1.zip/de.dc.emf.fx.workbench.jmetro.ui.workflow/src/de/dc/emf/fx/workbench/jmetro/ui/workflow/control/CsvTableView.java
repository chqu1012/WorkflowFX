package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.commons.io.FileUtils;

import de.dc.emf.fx.workbench.jmetro.ui.EmfFxmlBorderPane;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.util.Callback;

public class CsvTableView extends EmfFxmlBorderPane{
	
    @FXML
    protected TextField textSplitBy;

    @FXML
    protected TextField textFilePath;

    @FXML
    protected TextField textSearch;

    @FXML
    protected TextField tetxStartLineIndex;

    @FXML
    protected TextField tetxEndLineIndex;

    @FXML
    protected Button buttonParse;

    @FXML
    protected TableView<ObservableList<String>> tableView;

    @FXML
    protected Label labelDataSize;
    
    private ObservableList<ObservableList<String>> masterData = FXCollections.observableArrayList();
	private FilteredList<ObservableList<String>> filteredData = new FilteredList<>(masterData);
	private SortedList<ObservableList<String>> sortedData = new SortedList<>(filteredData);

	private CsvTableParser csvParser;
	
    public CsvTableView(CsvTableParser csvParser) {
    	super("/de/dc/emf/fx/workbench/jmetro/ui/workflow/CsvTableView.fxml");
		this.csvParser = csvParser;
    	
    	tableView.setItems(sortedData);
    	textSearch.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (newValue!=null) {
					filteredData.setPredicate(p->{
						for (String property : p) {
							if (property.toLowerCase().contains(newValue.toLowerCase())) {
								return true;
							}
						}
						return false;
					});
				}
			}
		});
    	labelDataSize.textProperty().bind(Bindings.size(masterData).asString().concat(" Row(s)"));
    	
    	textFilePath.setText(csvParser.getFilePath());
    	textSplitBy.setText(csvParser.getSplitBy());
    	tetxStartLineIndex.setText(String.valueOf(csvParser.getStartIndex()));
    	tetxEndLineIndex.setText(String.valueOf(csvParser.getEndIndex()));
    }

	public void setInput(ObservableList<ObservableList<String>> dataList) {
		this.masterData.setAll(dataList);
	}

	public void clear() {
		this.masterData.clear();
	}
	
	public void add(ObservableList<String> data) {
		this.masterData.add(data);
	}
	
	public void createColumns(String... columns) {
		for (int i = 0; i < columns.length; i++) {
			createColumn(i, columns[i]);
		}
	}
	
	public void createColumn(int index, String property) {
		 TableColumn col = new TableColumn<>(property.toUpperCase());
		 col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
             public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                 return new SimpleStringProperty(param.getValue().get(index).toString());                        
             }                    
         });
         tableView.getColumns().addAll(col); 
	}
    
    @FXML
    protected void onButtonOpenAction(ActionEvent event) {
    	FileChooser fc = new FileChooser();
    	fc.setSelectedExtensionFilter(new ExtensionFilter("CSV File(s)", "*.csv", "*.*"));
    	File file = fc.showOpenDialog(new Stage());
    	if (file != null) {
    		textFilePath.setText(file.getAbsolutePath());
		}
    	
    }

    @FXML
    protected void onButtonParseAction(ActionEvent event) {
    	try {
    		reset();

    		String splitBy = textSplitBy.getText();
    		String filePath = textFilePath.getText();
    		
    		csvParser.setFilePath(filePath);
    		csvParser.setSplitBy(splitBy);
    		csvParser.setEndIndex(Integer.parseInt(tetxEndLineIndex.getText()));
    		csvParser.setStartIndex(Integer.parseInt(tetxStartLineIndex.getText()));
    		
			List<String> lines = FileUtils.readLines(new File(filePath), StandardCharsets.UTF_8);
			for (int i = 0; i < lines.size(); i++) {
				String[] fields = lines.get(i).split(splitBy);
				if (i==0) {
					createColumns(fields);
				}else {
					add(FXCollections.observableArrayList(fields));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

	private void reset() {
		tableView.getColumns().clear();
		masterData.clear();
	}
}
