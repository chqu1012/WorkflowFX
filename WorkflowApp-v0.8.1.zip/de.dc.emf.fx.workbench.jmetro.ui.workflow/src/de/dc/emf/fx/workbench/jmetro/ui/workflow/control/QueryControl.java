package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.dc.emf.fx.workbench.jmetro.ui.dialog.ErrorDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Query;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.DBHelper;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.ReplacementSwitch;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class QueryControl extends VBox {

	private static final Logger LOG = Logger.getLogger(QueryControl.class.getSimpleName());

	private static ReplacementSwitch replacements = new ReplacementSwitch();
	private ObservableList<ObservableList<String>> masterData = FXCollections.observableArrayList();
	private FilteredList<ObservableList<String>> filteredData = new FilteredList<>(masterData);
	private SortedList<ObservableList<String>> sortedData = new SortedList<>(filteredData);
	
	public QueryControl(Query object) {
		String sql = replacements.doSwitch(object);
		getChildren().add(new Label("Query:"));
		getChildren().add(new TextField(sql));
		
		TextField textField = new TextField();
		textField.setPromptText("Filter table...");
		
		TableView<ObservableList<String>> tableView = new TableView<>();
		tableView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		VBox.setVgrow(tableView, Priority.ALWAYS);
		sortedData.comparatorProperty().bind(tableView.comparatorProperty());
		tableView.setItems(sortedData);

		Button buttonOpenConnection = new Button("Open Connection");
		buttonOpenConnection.setOnMouseClicked(e -> {
			DBTableView dbTable = (DBTableView) object.eContainer();
			DBConfig config = dbTable.getDatabase();
			DBHelper helper = new DBHelper(config.getJdbcDriver(), config.getDbUrl(), config.getUser(),
					config.getPassword());

			helper.openConnection();
			try {
				masterData.clear();
				
				LOG.log(Level.INFO, "Queried: {0}", sql);
				ResultSet rs = helper.query(sql);
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
				if (tableView.getColumns().isEmpty()) {
					for (int i = 0; i < columnCount; i++) {
						final int j = i;
						String columnName = metaData.getColumnName(i + 1);
						TableColumn<ObservableList<String>, String> col = new TableColumn<>(columnName);
						col.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(j).toString()));
						col.setCellFactory(TextFieldTableCell.forTableColumn());
						col.setText(columnName);
						tableView.getColumns().add(col);
					}
				}
				while (rs.next()) {
					ObservableList<String> row = FXCollections.observableArrayList();
					for (int i = 0; i < columnCount; i++) {
						row.add(rs.getString(i + 1));
					}
					masterData.add(row);
				}
			} catch (SQLException e1) {
				new ErrorDialog(e1).open();
			}
			helper.closeConnection();
		});
		
		textField.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (newValue!=null) {
					filteredData.setPredicate(e->{
						boolean result = false;
						for (String columntext : e) {
							if (columntext.toLowerCase().contains(newValue.toLowerCase())) {
								return true;
							}
						}
						return result;
					});
				}
			}
		});
		
		getChildren().add(buttonOpenConnection);
		getChildren().add(textField);
		getChildren().add(tableView);
		
		setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		VBox.setVgrow(this, Priority.ALWAYS);
	}
}
