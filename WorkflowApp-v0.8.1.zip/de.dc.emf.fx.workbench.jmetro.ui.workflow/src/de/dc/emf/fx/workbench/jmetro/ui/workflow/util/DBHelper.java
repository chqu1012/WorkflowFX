package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DBHelper {

	private Connection conn;
	private String dbUrl;
	private String user;
	private String password;
	private Statement currentStatement;

	public DBHelper(String driver, String dbUrl, String user, String password) {
		this.dbUrl = dbUrl;
		this.user = user;
		this.password = password;
		try {
			// STEP 1: Register JDBC driver
			Class.forName(driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ResultSet query(String sql) throws SQLException {
		currentStatement = conn.createStatement();
		ResultSet resultSet = currentStatement.executeQuery(sql);
		return resultSet;
	}
	
	public void closeStatement() {
		try {
			this.currentStatement.closeOnCompletion();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void openConnection() {
		// STEP 2: Open a connection
		System.out.println("Connecting to database...");
		try {
			conn = DriverManager.getConnection(dbUrl, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static ResultSet getRows(String driver, String dbUrl, String user, String password, String sql) {
		Connection conn = null;
		try {
			// STEP 1: Register JDBC driver
			Class.forName(driver);

			// STEP 2: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(dbUrl, user, password);

			Statement stmt = conn.createStatement();
			ResultSet resultSet = stmt.executeQuery(sql);
			stmt.close();
			conn.close();

			System.out.println("Closed database...");
			return resultSet;
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static List<String> getColumnNames(String driver, String dbUrl, String user, String password, String sql) {
		List<String> names = new ArrayList<>();
		Connection conn = null;
		try {
			// STEP 1: Register JDBC driver
			Class.forName(driver);

			// STEP 2: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(dbUrl, user, password);

			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSetMetaData mymeta = stmt.getMetaData();
			for (int i = 0; i < mymeta.getColumnCount(); i++) {
				String name = mymeta.getColumnName(i + 1);
				names.add(name);
			}

			stmt.close();
			conn.close();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} // end try
		return names;
	}

	public static void openConnection(String JDBC_DRIVER, String DB_URL, String USER, String PASS) {
		Connection conn = null;
		Statement stmt = null;
		try {
			// STEP 1: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			// STEP 2: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 3: Execute a query
			System.out.println("Creating table in given database...");
			stmt = conn.createStatement();
			String sql = "CREATE TABLE   REGISTRATION " + "(id INTEGER not NULL, " + " first VARCHAR(255), "
					+ " last VARCHAR(255), " + " age INTEGER, " + " PRIMARY KEY ( id ))";
			stmt.executeUpdate(sql);
			System.out.println("Created table in given database...");

			// STEP 4: Clean-up environment
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} // end finally try
		} // end try
		System.out.println("Goodbye!");
	}
}
