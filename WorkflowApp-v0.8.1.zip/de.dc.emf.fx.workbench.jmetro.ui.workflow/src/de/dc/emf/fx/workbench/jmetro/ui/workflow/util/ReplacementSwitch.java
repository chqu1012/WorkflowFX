package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.eclipse.emf.common.util.EList;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Option;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Path;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Query;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.TextInputDialog;

public class ReplacementSwitch extends WorkflowSwitch<String> {

	@Override
	public String caseQuery(Query object) {
		String content = object.getContent();
		for (Replacement replacement : object.getReplacements()) {
			String c = doSwitch(replacement.getReplacer());
			if (c != null) {
				content = content.replaceAll(replacement.getVariable(), c);
			}
		}
		return content;
	}

	@Override
	public String caseStringReplacer(StringReplacer object) {
		String paste = paste();
		paste = paste.replaceAll(object.getRegex(), object.getReplacer());
		for (Replacement replacement : object.getReplacements()) {
			String content = doSwitch(replacement.getReplacer());
			paste = paste.replaceAll(replacement.getVariable(), content);
		}
		return paste;
	}

	@Override
	public String caseStringSeparator(StringSeparator object) {
		String paste = paste();
		paste = paste.replaceAll(object.getLineSeparator(), "\n");
		for (Replacement replacement : object.getReplacements()) {
			String content = doSwitch(replacement.getReplacer());
			paste = paste.replaceAll(replacement.getVariable(), content);
		}
		return paste;
	}

	@Override
	public String caseClipboard(Clipboard object) {
		String content = object.getContent();
		for (Replacement replacement : object.getReplacements()) {
			String c = doSwitch(replacement.getReplacer());
			if (c != null) {
				content = content.replaceAll(replacement.getVariable(), c);
			}
		}
		return content;
	}

	@Override
	public String casePath(Path object) {
		String content = object.getContent();
		for (Replacement replacement : object.getReplacements()) {
			Replacer replacer = replacement.getReplacer();
			if (replacer != null) {
				String c = doSwitch(replacer);
				if (c != null) {
					content = content.replaceAll(replacement.getVariable(), c);
				}
			}
		}
		return content;
	}

	@Override
	public String caseReplacer(Replacer object) {
		return object.getValue();
	}

	@Override
	public String caseInputReplacer(InputReplacer object) {
		TextInputDialog dialog = new TextInputDialog(object.getValue());
		dialog.setTitle(object.getTitle());
		dialog.setHeaderText(object.getMessage());
		dialog.setContentText("Please enter your name:");
		Optional<String> result = dialog.showAndWait();
		if (result.isPresent()){
		   return result.get();
		}
		return "";
	}

	@Override
	public String caseTimestampReplacer(TimestampReplacer object) {
		SimpleDateFormat sdf = new SimpleDateFormat(object.getFormatter());
		return sdf.format(System.currentTimeMillis());
	}

	@Override
	public String caseOptionReplacer(OptionReplacer object) {
		EList<Option> options = object.getOptions();
		List<String> optionValues = new ArrayList<>();
		for (Option option : options) {
			optionValues.add(option.getName());
		}
		ChoiceDialog<String> dialog = new ChoiceDialog<>(null, optionValues);
		dialog.setTitle("Choice Dialog");
		dialog.setHeaderText("Select a element");
		dialog.setContentText("Element:");

		Optional<String> result = dialog.showAndWait();
		if (result.isPresent()) {
			return result.get();
		}
		return StringUtils.EMPTY;
	}

	public String paste() {
		try {
			java.awt.datatransfer.Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
			Transferable t = cb.getContents(null);
			if (t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
				return t.getTransferData(DataFlavor.stringFlavor).toString();
			}
		} catch (UnsupportedFlavorException | IOException ex) {
			return "";
		}
		return "";
	}
}
