package de.dc.emf.fx.workbench.jmetro.ui.workflow.dialog;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;

import com.google.common.base.Charsets;

import de.dc.emf.fx.workbench.jmetro.ui.dialog.ErrorDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Control;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Item;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class GenericInputDialog extends VBox {

	private Map<Control, Node> controls = new HashMap<>();
	private TextArea textArea;
	private InputDialog object;
	private File templateFolder = new File("./config/plugins/workflow/templates");

	public GenericInputDialog(InputDialog object) {
		this.object = object;
		
		if (object.isUseTemplate()) {
			if (!templateFolder.exists()) {
				templateFolder.mkdir();
			}
		}
		
		setPadding(new Insets(5d));

		Label label = new Label("Input Dialog");
		Font font = new Font(20);
		label.setFont(font);
		getChildren().add(label);
	}

	public void addControl(Control control, Node node) {
		Label label = new Label(control.getVariable().replace("%", "") + ":");
		label.setPrefWidth(120);
		getChildren().add(label);
		getChildren().add(node);
		controls.put(control, node);
	}

	public void create() {
		HBox hbox = new HBox(5);

		Button buttonShowContent = new Button("Show content");
		buttonShowContent.setOnAction(e -> {
			String content = object.getContent();
			if (object.isUseTemplate()) {
				try {
					content = FileUtils.readFileToString(new File(templateFolder.getAbsolutePath()+"/"+object.getTemplateName()), Charsets.UTF_8);
				} catch (IOException e1) {
					new ErrorDialog(e1).open();
				}
			}
			for (Entry<Control, Node> c : controls.entrySet()) {
				String variable = c.getKey().getVariable();
				String value = getvalue(c);
				content = content.replaceAll(variable, value);
			}
			textArea.setText(content);
		});

		hbox.getChildren().add(new Button("Reset"));
		hbox.getChildren().add(buttonShowContent);
		hbox.getChildren().add(new Button("Copy to Clipboard"));
		getChildren().add(hbox);

		textArea = new TextArea();
		VBox.setVgrow(textArea, Priority.ALWAYS);
		getChildren().add(textArea);
	}

	private String getvalue(Entry<Control, Node> c) {
		String value = "";
		if (c.getValue() instanceof TextField) {
			TextField control = (TextField) c.getValue();
			value = control.getText() == null? "" : control.getText();
		} else if (c.getValue() instanceof DatePicker) {
			DatePicker control = (DatePicker) c.getValue();
			DateControl dateControl = (DateControl) c.getKey();
			if ( control.getValue() != null) {
				value=control.getValue().format(DateTimeFormatter.ofPattern(dateControl.getFormatter()));
			}
		} else if (c.getValue() instanceof ComboBox) {
			ComboBox<ComboItem> control = (ComboBox<ComboItem>) c.getValue();
			ComboItem selection = control.getSelectionModel().getSelectedItem();
			if (selection != null) {
				value = selection.getValue();
			}
		}else if (c.getValue() instanceof ListView) {
			ListView<Item> control = (ListView<Item>) c.getValue();
			Item selection = control.getSelectionModel().getSelectedItem();
			if (selection!=null) {
				value = selection.getValue();
			}
		}
		return value;
	}
}
