package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.OperationSwitch;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.ReplacementSwitch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class MkdirControl extends VBox{

	private ReplacementSwitch replacements = new ReplacementSwitch();
	private OperationSwitch operations = new OperationSwitch();
	
	public MkdirControl(Mkdir object) {
		HBox parent = new HBox(5);
		parent.setSpacing(5);
		parent.setAlignment(Pos.CENTER_LEFT);
		parent.setPadding(new Insets(5));
		parent.getChildren().add(new Label("Mkdir"));
		
		TextField textField = new TextField(object.getPath().getContent());
		textField.setEditable(false);
		HBox.setHgrow(textField, Priority.ALWAYS);
		parent.getChildren().add(textField);
		Button buttonCreate = new Button("Create");
		parent.getChildren().add(buttonCreate);
		
		getChildren().add(parent);
		
		parent = new HBox(5);
		parent.getChildren().add(new Label("\t\t"));
		Hyperlink hyperlink = new Hyperlink();
		hyperlink.setStyle("-fx-font-size: 10");
		parent.getChildren().add(hyperlink);
		
		hyperlink.setOnMouseClicked(e->{
			try {
				Desktop.getDesktop().open(new File(replacements.doSwitch(object.getPath())));
			} catch (IOException e1) {
				e1.printStackTrace();
//				EmfFXPlatform.getInstance(ILogService.class).error("Could not open folder "+textField.getText(), e1);
			}
		});
		buttonCreate.setOnAction(e->{
			operations.doSwitch(object);
			String path = replacements.doSwitch(object.getPath());
			hyperlink.setText(path);
		});
		
		getChildren().add(parent);
	}
}
