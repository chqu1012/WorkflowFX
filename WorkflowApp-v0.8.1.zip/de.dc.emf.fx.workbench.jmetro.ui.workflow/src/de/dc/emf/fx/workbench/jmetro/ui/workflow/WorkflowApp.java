package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import de.dc.emf.fx.workbench.jmetro.core.di.EmfFXPlatform;
import de.dc.emf.fx.workbench.jmetro.modul.Modul;
import de.dc.emf.fx.workbench.jmetro.modul.file.ModuleFile;
import de.dc.emf.fx.workbench.jmetro.ui.EmfApplication;
import de.dc.emf.fx.workbench.jmetro.ui.EmfWorkbench;
import de.dc.emf.fx.workbench.jmetro.ui.service.IWorkbenchService;

public class WorkflowApp extends EmfApplication{

	@Override
	protected void initWorkbench(EmfWorkbench workbench) {
		ModuleFile moduleFile = new ModuleFile();
		Modul modul = moduleFile.load("./base.modul");
		EmfFXPlatform.getInstance(IWorkbenchService.class).registrateModul(workbench, modul);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
