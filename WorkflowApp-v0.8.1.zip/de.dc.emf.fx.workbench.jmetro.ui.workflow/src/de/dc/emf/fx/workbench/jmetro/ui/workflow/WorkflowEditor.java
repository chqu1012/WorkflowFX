package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import de.dc.emf.fx.workbench.jmetro.ui.SimpleEmfEditor;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.provider.WorkflowItemProviderAdapterFactory;

public class WorkflowEditor extends SimpleEmfEditor<WorkflowManager>{

	@Override
	protected AdapterFactory getModelItemProviderAdapterFactory() {
		return new WorkflowItemProviderAdapterFactory();
	}

	@Override
	protected String getEFilextension() {
		return WorkflowPackage.eNAME;
	}

	@Override
	protected EObject createRootModel() {
		return WorkflowFactory.eINSTANCE.createWorkflowManager();
	}

	@Override
	protected EFactory getEFactory() {
		return WorkflowFactory.eINSTANCE;
	}

	@Override
	protected EPackage getEPackage() {
		return WorkflowPackage.eINSTANCE;
	}

}
