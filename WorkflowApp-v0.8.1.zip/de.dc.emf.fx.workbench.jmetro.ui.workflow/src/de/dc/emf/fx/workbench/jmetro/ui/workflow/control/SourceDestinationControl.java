package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import java.io.File;
import java.util.function.Consumer;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Path;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowFactory;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.OperationSwitch;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.util.ReplacementSwitch;
import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class SourceDestinationControl<T extends Copy> extends VBox{

	protected ReplacementSwitch replacements = new ReplacementSwitch();
	protected OperationSwitch operations = new OperationSwitch();
	
	protected T object;
	private Button button;
	protected TextField textSource;
	protected TextField textDestination;
	
	public SourceDestinationControl(T object, String buttonName) {
		this.object = object;
		
		setStyle("-fx-border-color: lightgray;");
		
		setSpacing(5);
		setPadding(new Insets(5d));
		
		textSource = createFileText("Source:", true, this::consumerSource);
		textDestination = createFileText("Destination:", false, this::consumerDestination);
		
		ProgressBar progressBar = new ProgressBar(0);
		progressBar.setMaxWidth(Double.MAX_VALUE);
		getChildren().add(progressBar);
		
		if (object.getSource() != null) {
			Path source = object.getSource();
			String sourcePath = replacements.doSwitch(source);
			textSource.setText(sourcePath);
		} 
		if (object.getDestination() != null) {
			Path destination = object.getDestination();
			String destinationPath = replacements.doSwitch(destination);
			textDestination.setText(destinationPath);
		}
		
		button = new Button(buttonName);
		button.setMaxWidth(Double.MAX_VALUE);
		button.setOnAction(e->{
			progressBar.setProgress(0);
			onButtonAction();
			progressBar.setProgress(100);
		});
		getChildren().add(button);

		BooleanBinding disableProperty = textSource.textProperty().isEmpty().or(textDestination.textProperty().isEmpty());
		button.disableProperty().bind(disableProperty);
	}
	
	protected void consumerDestination(File file) {
		if (object.getDestination()==null) {
			object.setDestination(WorkflowFactory.eINSTANCE.createPath());
		}
		String path = file.getAbsolutePath();
		object.getDestination().setContent(path);
		textDestination.setText(path);
	}

	protected void consumerSource(File file) {
		if (object.getSource()==null) {
			object.setSource(WorkflowFactory.eINSTANCE.createPath());
		}
		String path = file.getAbsolutePath();
		object.getSource().setContent(path);
		textSource.setText(path);
	}

	protected void onButtonAction() {
		operations.doSwitch(object);
	}

	protected void setButtonName(String name) {
		button.setText(name);
	}
	
	protected TextField createFileText(String name, boolean isOpen, Consumer<File> consumer) {
		HBox hbox = new HBox(5);
		hbox.setAlignment(Pos.CENTER_LEFT);
		hbox.setPadding(new Insets(5));
		Label label = new Label(name);
		label.setPrefWidth(120);
		hbox.getChildren().add(label);
		TextField textField = new TextField();
		textField.setEditable(false);
		textField.setMaxWidth(Double.MAX_VALUE);
		HBox.setHgrow(textField, Priority.ALWAYS);
		hbox.getChildren().add(textField);
		Button button = new Button("...");
		button.setOnAction(e->onOpenDialog(e, textField, isOpen, consumer));
		hbox.getChildren().add(button);
		getChildren().add(hbox);
		
		return textField;
	}
	
	private void onOpenDialog(ActionEvent e, TextField textField, boolean isOpen, Consumer<File> consumer) {
		FileChooser fc = new FileChooser();
		File file = isOpen ? fc.showOpenDialog(new Stage()) : fc.showSaveDialog(new Stage());
		if (file != null) {
			consumer.accept(file);
		}
	}
}
