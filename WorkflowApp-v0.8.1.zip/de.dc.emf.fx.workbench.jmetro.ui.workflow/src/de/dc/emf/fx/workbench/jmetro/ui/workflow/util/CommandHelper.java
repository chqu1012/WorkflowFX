package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS;

public class CommandHelper {

	private CommandHelper() {
		// Helper Class
	}
	
	public static void exe(String command) {
		try {
			Runtime.getRuntime().exec(command);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void exeSSMS(SSMS object) {
		StringBuilder sb = new StringBuilder("ssms.exe ");

		// Sevrer
		sb.append("-S").append(" ").append(object.getServer()).append(" ");

		// Database
		String db = object.getDatabase();
		if (StringUtils.isNotEmpty(db)) {
			sb.append("-d").append(" ").append(db).append(" ");
		}

		// User and Password
		sb.append("-U").append(" ").append(object.getUser()).append(" ");
		sb.append("-P").append(" ").append(object.getPassword()).append(" ");

		if (object.isNoSplash()) {
			sb.append("-nosplash").append(" ");
		}

		exe(sb.toString());
	}
}
