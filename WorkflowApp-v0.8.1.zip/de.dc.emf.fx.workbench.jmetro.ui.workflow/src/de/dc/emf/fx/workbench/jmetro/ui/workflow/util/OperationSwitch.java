package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Move;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Path;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Zip;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.dialog.PasswordDialog;
import javafx.scene.input.ClipboardContent;

public class OperationSwitch extends WorkflowSwitch<Object> {

	private static final Logger LOG = Logger.getLogger(OperationSwitch.class.getSimpleName());

	private ReplacementSwitch replaceSwith = new ReplacementSwitch();

	@Override
	public Object caseZip(Zip object) {
		Path destination = object.getDestination();
		String destinationPath = replaceSwith.doSwitch(destination);
		Path source = object.getSource();
		String sourcePath = replaceSwith.doSwitch(source);

		try (FileOutputStream fos = new FileOutputStream(destinationPath)) {
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			File fileToZip = new File(sourcePath);
			FileInputStream fis = new FileInputStream(fileToZip);
			ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
			zipOut.putNextEntry(zipEntry);
			byte[] bytes = new byte[1024];
			int length;
			while ((length = fis.read(bytes)) >= 0) {
				zipOut.write(bytes, 0, length);
			}
			zipOut.closeEntry();
			zipOut.close();
			fis.close();
		} catch (IOException e) {
			LOG.log(Level.SEVERE, "Failed to zip " + sourcePath);
		}
		return super.caseZip(object);
	}

	@Override
	public Object caseMove(Move object) {
		Path destination = object.getDestination();
		String destinationPath = replaceSwith.doSwitch(destination);
		Path source = object.getSource();
		String sourcePath = replaceSwith.doSwitch(source);

		try {
			FileUtils.moveFile(new File(sourcePath), new File(destinationPath));
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage());
		}

		return super.caseMove(object);
	}

	@Override
	public Object caseCopy(Copy object) {
		boolean isZip = object instanceof Zip;
		boolean isMove = object instanceof Move;
		if (!isZip && !isMove) {
			Path destination = object.getDestination();
			String destinationPath = replaceSwith.doSwitch(destination);
			Path source = object.getSource();
			String sourcePath = replaceSwith.doSwitch(source);
			try {
				FileUtils.copyFile(new File(sourcePath), new File(destinationPath));
			} catch (IOException e) {
				LOG.log(Level.SEVERE, e.getMessage());
			}
		}
		return super.caseCopy(object);
	}

	@Override
	public Object caseSSMS(SSMS object) {
		CommandHelper.exeSSMS(object);
		return super.caseSSMS(object);
	}

	@Override
	public Object caseRemoteDesktop(RemoteDesktop object) {
		String password = object.getPassword();
		if (StringUtils.isEmpty(password)) {
			PasswordDialog dialog = new PasswordDialog();
			Optional<String> result = dialog.showAndWait();
			result.ifPresent(pwd -> RemoteDesktopRunner.run(object, password));
		}else {
			RemoteDesktopRunner.run(object, password);
		}
		
		return super.caseRemoteDesktop(object);
	}

	@Override
	public Object caseInputDialog(InputDialog object) {
		String result = object.getContent();
		clipboard(result);
		return super.caseInputDialog(object);
	}

	@Override
	public Object caseExe(Exe object) {
		Path path = object.getPath();
		if (path != null) {
			String content = replaceSwith.doSwitch(path);
			LOG.log(Level.INFO, "caseExe: {0}", content);
			switch (object.getExeType()) {
			case COMMAND:
				CommandHelper.exe(content);
				break;
			case FILE:
				open(content);
				break;
			case FOLDER:
				open(content);
				break;
			case LINK:
				openBrowser(content);
				break;
			default:
				LOG.log(Level.SEVERE, "caseExe: Failed to open {0}", content);
				break;
			}
		}
		return null;
	}

	@Override
	public Object caseClipboard(Clipboard object) {
		String content = replaceSwith.doSwitch(object);
		clipboard(content);
		return content;
	}

	@Override
	public Object caseMkdir(Mkdir object) {
		String pathContent = replaceSwith.doSwitch(object.getPath());
		new File(pathContent).mkdir();
		return super.caseMkdir(object);
	}

	@Override
	public Object caseStringSeparator(StringSeparator object) {
		String content = replaceSwith.doSwitch(object);
		clipboard(content);
		return super.caseStringSeparator(object);
	}

	@Override
	public Object caseStringReplacer(StringReplacer object) {
		String content = replaceSwith.doSwitch(object);
		clipboard(content);
		return super.caseStringReplacer(object);
	}

	@Override
	public Object casePath(Path object) {
		String path = replaceSwith.doSwitch(object);
		open(path);
		return super.casePath(object);
	}

	public void clipboard(String text) {
		javafx.scene.input.Clipboard clipboard = javafx.scene.input.Clipboard.getSystemClipboard();
		ClipboardContent content = new ClipboardContent();
		content.putString(text);
		clipboard.setContent(content);
	}

	public void open(String path) {
		try {
			File file = new File(path);
			Desktop.getDesktop().open(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void openBrowser(String path) {
		try {
			Desktop.getDesktop().browse(new URI(path));
		} catch (IOException | URISyntaxException e) {
			e.printStackTrace();
		}
	}
}
