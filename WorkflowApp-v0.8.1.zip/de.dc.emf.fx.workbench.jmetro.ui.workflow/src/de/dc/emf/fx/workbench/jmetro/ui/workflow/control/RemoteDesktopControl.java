package de.dc.emf.fx.workbench.jmetro.ui.workflow.control;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

public class RemoteDesktopControl extends HBox{
	
	private Button button = new Button("Connect");

	public RemoteDesktopControl(RemoteDesktop object) {
		setSpacing(5);
		setPadding(new Insets(5));
		setAlignment(Pos.CENTER_LEFT);
		
		Label label = new Label(object.getName());
		label.setPrefWidth(120);
		
		TextField controlServer = new TextField();
		controlServer.setEditable(false);
		controlServer.setText(object.getServer());
		controlServer.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		HBox.setHgrow(controlServer, Priority.ALWAYS);
		
		TextField controlUser = new TextField();
		controlUser.setEditable(false);
		controlUser.setText(object.getUser());
		controlUser.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		HBox.setHgrow(controlUser, Priority.ALWAYS);
		
		PasswordField controlPassword = new PasswordField();
		controlPassword.setEditable(false);
		controlPassword.setText(object.getUser());
		controlPassword.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		HBox.setHgrow(controlPassword, Priority.ALWAYS);

		getChildren().add(label);
		getChildren().add(controlServer);
		getChildren().add(controlUser);
		getChildren().add(controlPassword);
		getChildren().add(button);
	}
	
	public void setOnAction(Runnable r) {
		button.setOnAction(e->r.run());
	}
}
