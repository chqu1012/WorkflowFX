/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Csv Table Parser</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getFilePath <em>File Path</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getStartIndex <em>Start Index</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getEndIndex <em>End Index</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getSplitBy <em>Split By</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCsvTableParser()
 * @model
 * @generated
 */
public interface CsvTableParser extends View {
	/**
	 * Returns the value of the '<em><b>File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Path</em>' attribute.
	 * @see #setFilePath(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCsvTableParser_FilePath()
	 * @model unique="false"
	 * @generated
	 */
	String getFilePath();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getFilePath <em>File Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Path</em>' attribute.
	 * @see #getFilePath()
	 * @generated
	 */
	void setFilePath(String value);

	/**
	 * Returns the value of the '<em><b>Start Index</b></em>' attribute.
	 * The default value is <code>"1"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Index</em>' attribute.
	 * @see #setStartIndex(int)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCsvTableParser_StartIndex()
	 * @model default="1" unique="false"
	 * @generated
	 */
	int getStartIndex();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getStartIndex <em>Start Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Index</em>' attribute.
	 * @see #getStartIndex()
	 * @generated
	 */
	void setStartIndex(int value);

	/**
	 * Returns the value of the '<em><b>End Index</b></em>' attribute.
	 * The default value is <code>"100"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Index</em>' attribute.
	 * @see #setEndIndex(int)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCsvTableParser_EndIndex()
	 * @model default="100" unique="false"
	 * @generated
	 */
	int getEndIndex();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getEndIndex <em>End Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Index</em>' attribute.
	 * @see #getEndIndex()
	 * @generated
	 */
	void setEndIndex(int value);

	/**
	 * Returns the value of the '<em><b>Split By</b></em>' attribute.
	 * The default value is <code>";"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Split By</em>' attribute.
	 * @see #setSplitBy(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCsvTableParser_SplitBy()
	 * @model default=";" unique="false"
	 * @generated
	 */
	String getSplitBy();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getSplitBy <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Split By</em>' attribute.
	 * @see #getSplitBy()
	 * @generated
	 */
	void setSplitBy(String value);

} // CsvTableParser
