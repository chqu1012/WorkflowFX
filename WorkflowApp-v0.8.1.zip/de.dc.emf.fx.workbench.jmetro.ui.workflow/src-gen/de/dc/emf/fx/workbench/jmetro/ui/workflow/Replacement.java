/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Replacement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getVariable <em>Variable</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getReplacer <em>Replacer</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getReplacement()
 * @model
 * @generated
 */
public interface Replacement extends EObject {
	/**
	 * Returns the value of the '<em><b>Variable</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variable</em>' attribute.
	 * @see #setVariable(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getReplacement_Variable()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getVariable();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getVariable <em>Variable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Variable</em>' attribute.
	 * @see #getVariable()
	 * @generated
	 */
	void setVariable(String value);

	/**
	 * Returns the value of the '<em><b>Replacer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Replacer</em>' containment reference.
	 * @see #setReplacer(Replacer)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getReplacement_Replacer()
	 * @model containment="true"
	 * @generated
	 */
	Replacer getReplacer();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getReplacer <em>Replacer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Replacer</em>' containment reference.
	 * @see #getReplacer()
	 * @generated
	 */
	void setReplacer(Replacer value);

} // Replacement
