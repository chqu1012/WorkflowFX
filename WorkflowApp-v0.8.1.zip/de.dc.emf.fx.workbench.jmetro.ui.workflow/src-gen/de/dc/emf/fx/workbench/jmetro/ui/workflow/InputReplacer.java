/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Replacer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getTitle <em>Title</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getMessage <em>Message</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputReplacer()
 * @model
 * @generated
 */
public interface InputReplacer extends Replacer {
	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputReplacer_Title()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>Message</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message</em>' attribute.
	 * @see #setMessage(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputReplacer_Message()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getMessage();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getMessage <em>Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Message</em>' attribute.
	 * @see #getMessage()
	 * @generated
	 */
	void setMessage(String value);

} // InputReplacer
