/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Copy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getStyle <em>Style</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getSource <em>Source</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getDestination <em>Destination</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCopy()
 * @model
 * @generated
 */
public interface Copy extends Operation {
	/**
	 * Returns the value of the '<em><b>Style</b></em>' attribute.
	 * The default value is <code>"Detail"</code>.
	 * The literals are from the enumeration {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Style</em>' attribute.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle
	 * @see #setStyle(FormStyle)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCopy_Style()
	 * @model default="Detail" unique="false"
	 * @generated
	 */
	FormStyle getStyle();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getStyle <em>Style</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Style</em>' attribute.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle
	 * @see #getStyle()
	 * @generated
	 */
	void setStyle(FormStyle value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' containment reference.
	 * @see #setSource(Path)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCopy_Source()
	 * @model containment="true"
	 * @generated
	 */
	Path getSource();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getSource <em>Source</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' containment reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Path value);

	/**
	 * Returns the value of the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination</em>' containment reference.
	 * @see #setDestination(Path)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getCopy_Destination()
	 * @model containment="true"
	 * @generated
	 */
	Path getDestination();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getDestination <em>Destination</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination</em>' containment reference.
	 * @see #getDestination()
	 * @generated
	 */
	void setDestination(Path value);

} // Copy
