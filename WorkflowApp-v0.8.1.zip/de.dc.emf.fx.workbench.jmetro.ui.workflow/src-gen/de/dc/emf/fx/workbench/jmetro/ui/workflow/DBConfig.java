/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DB Config</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getJdbcDriver <em>Jdbc Driver</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getDbUrl <em>Db Url</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getQuery <em>Query</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getUser <em>User</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getPassword <em>Password</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig()
 * @model
 * @generated
 */
public interface DBConfig extends EObject {
	/**
	 * Returns the value of the '<em><b>Jdbc Driver</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Jdbc Driver</em>' attribute.
	 * @see #setJdbcDriver(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig_JdbcDriver()
	 * @model unique="false"
	 * @generated
	 */
	String getJdbcDriver();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getJdbcDriver <em>Jdbc Driver</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Jdbc Driver</em>' attribute.
	 * @see #getJdbcDriver()
	 * @generated
	 */
	void setJdbcDriver(String value);

	/**
	 * Returns the value of the '<em><b>Db Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Db Url</em>' attribute.
	 * @see #setDbUrl(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig_DbUrl()
	 * @model unique="false"
	 * @generated
	 */
	String getDbUrl();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getDbUrl <em>Db Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Db Url</em>' attribute.
	 * @see #getDbUrl()
	 * @generated
	 */
	void setDbUrl(String value);

	/**
	 * Returns the value of the '<em><b>Query</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Query</em>' attribute.
	 * @see #setQuery(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig_Query()
	 * @model unique="false"
	 * @generated
	 */
	String getQuery();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getQuery <em>Query</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Query</em>' attribute.
	 * @see #getQuery()
	 * @generated
	 */
	void setQuery(String value);

	/**
	 * Returns the value of the '<em><b>User</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User</em>' attribute.
	 * @see #setUser(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig_User()
	 * @model unique="false"
	 * @generated
	 */
	String getUser();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getUser <em>User</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User</em>' attribute.
	 * @see #getUser()
	 * @generated
	 */
	void setUser(String value);

	/**
	 * Returns the value of the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Password</em>' attribute.
	 * @see #setPassword(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBConfig_Password()
	 * @model unique="false"
	 * @generated
	 */
	String getPassword();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getPassword <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Password</em>' attribute.
	 * @see #getPassword()
	 * @generated
	 */
	void setPassword(String value);

} // DBConfig
