/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.impl;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.View;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl#isIsRunnable <em>Is Runnable</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl#getWorkflows <em>Workflows</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl#getDialogs <em>Dialogs</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl#getViews <em>Views</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WorkflowImpl extends NamedElementImpl implements Workflow {
	/**
	 * The default value of the '{@link #isIsRunnable() <em>Is Runnable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsRunnable()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_RUNNABLE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsRunnable() <em>Is Runnable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsRunnable()
	 * @generated
	 * @ordered
	 */
	protected boolean isRunnable = IS_RUNNABLE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operations;

	/**
	 * The cached value of the '{@link #getWorkflows() <em>Workflows</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWorkflows()
	 * @generated
	 * @ordered
	 */
	protected EList<Workflow> workflows;

	/**
	 * The cached value of the '{@link #getDialogs() <em>Dialogs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDialogs()
	 * @generated
	 * @ordered
	 */
	protected EList<InputDialog> dialogs;

	/**
	 * The cached value of the '{@link #getViews() <em>Views</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViews()
	 * @generated
	 * @ordered
	 */
	protected EList<View> views;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WorkflowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.WORKFLOW;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsRunnable() {
		return isRunnable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsRunnable(boolean newIsRunnable) {
		boolean oldIsRunnable = isRunnable;
		isRunnable = newIsRunnable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.WORKFLOW__IS_RUNNABLE, oldIsRunnable,
					isRunnable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operation> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operation>(Operation.class, this,
					WorkflowPackage.WORKFLOW__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Workflow> getWorkflows() {
		if (workflows == null) {
			workflows = new EObjectContainmentEList<Workflow>(Workflow.class, this,
					WorkflowPackage.WORKFLOW__WORKFLOWS);
		}
		return workflows;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InputDialog> getDialogs() {
		if (dialogs == null) {
			dialogs = new EObjectContainmentEList<InputDialog>(InputDialog.class, this,
					WorkflowPackage.WORKFLOW__DIALOGS);
		}
		return dialogs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<View> getViews() {
		if (views == null) {
			views = new EObjectContainmentEList<View>(View.class, this, WorkflowPackage.WORKFLOW__VIEWS);
		}
		return views;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case WorkflowPackage.WORKFLOW__OPERATIONS:
			return ((InternalEList<?>) getOperations()).basicRemove(otherEnd, msgs);
		case WorkflowPackage.WORKFLOW__WORKFLOWS:
			return ((InternalEList<?>) getWorkflows()).basicRemove(otherEnd, msgs);
		case WorkflowPackage.WORKFLOW__DIALOGS:
			return ((InternalEList<?>) getDialogs()).basicRemove(otherEnd, msgs);
		case WorkflowPackage.WORKFLOW__VIEWS:
			return ((InternalEList<?>) getViews()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case WorkflowPackage.WORKFLOW__IS_RUNNABLE:
			return isIsRunnable();
		case WorkflowPackage.WORKFLOW__OPERATIONS:
			return getOperations();
		case WorkflowPackage.WORKFLOW__WORKFLOWS:
			return getWorkflows();
		case WorkflowPackage.WORKFLOW__DIALOGS:
			return getDialogs();
		case WorkflowPackage.WORKFLOW__VIEWS:
			return getViews();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case WorkflowPackage.WORKFLOW__IS_RUNNABLE:
			setIsRunnable((Boolean) newValue);
			return;
		case WorkflowPackage.WORKFLOW__OPERATIONS:
			getOperations().clear();
			getOperations().addAll((Collection<? extends Operation>) newValue);
			return;
		case WorkflowPackage.WORKFLOW__WORKFLOWS:
			getWorkflows().clear();
			getWorkflows().addAll((Collection<? extends Workflow>) newValue);
			return;
		case WorkflowPackage.WORKFLOW__DIALOGS:
			getDialogs().clear();
			getDialogs().addAll((Collection<? extends InputDialog>) newValue);
			return;
		case WorkflowPackage.WORKFLOW__VIEWS:
			getViews().clear();
			getViews().addAll((Collection<? extends View>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case WorkflowPackage.WORKFLOW__IS_RUNNABLE:
			setIsRunnable(IS_RUNNABLE_EDEFAULT);
			return;
		case WorkflowPackage.WORKFLOW__OPERATIONS:
			getOperations().clear();
			return;
		case WorkflowPackage.WORKFLOW__WORKFLOWS:
			getWorkflows().clear();
			return;
		case WorkflowPackage.WORKFLOW__DIALOGS:
			getDialogs().clear();
			return;
		case WorkflowPackage.WORKFLOW__VIEWS:
			getViews().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case WorkflowPackage.WORKFLOW__IS_RUNNABLE:
			return isRunnable != IS_RUNNABLE_EDEFAULT;
		case WorkflowPackage.WORKFLOW__OPERATIONS:
			return operations != null && !operations.isEmpty();
		case WorkflowPackage.WORKFLOW__WORKFLOWS:
			return workflows != null && !workflows.isEmpty();
		case WorkflowPackage.WORKFLOW__DIALOGS:
			return dialogs != null && !dialogs.isEmpty();
		case WorkflowPackage.WORKFLOW__VIEWS:
			return views != null && !views.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (isRunnable: ");
		result.append(isRunnable);
		result.append(')');
		return result.toString();
	}

} //WorkflowImpl
