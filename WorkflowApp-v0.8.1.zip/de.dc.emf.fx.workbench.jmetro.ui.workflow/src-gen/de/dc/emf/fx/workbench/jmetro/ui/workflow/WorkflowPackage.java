/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowFactory
 * @model kind="package"
 * @generated
 */
public interface WorkflowPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "workflow";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.frateranatis.org/fx/emf/workflow";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "workflow";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WorkflowPackage eINSTANCE = de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl.init();

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowManagerImpl <em>Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowManagerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getWorkflowManager()
	 * @generated
	 */
	int WORKFLOW_MANAGER = 0;

	/**
	 * The feature id for the '<em><b>Workflows</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_MANAGER__WORKFLOWS = 0;

	/**
	 * The number of structural features of the '<em>Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_MANAGER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ContentImpl <em>Content</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ContentImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getContent()
	 * @generated
	 */
	int CONTENT = 9;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT__CONTENT = 0;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT__REPLACEMENTS = 1;

	/**
	 * The number of structural features of the '<em>Content</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Content</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.NamedElementImpl <em>Named Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.NamedElementImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getNamedElement()
	 * @generated
	 */
	int NAMED_ELEMENT = 11;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT__CONTENT = CONTENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT__REPLACEMENTS = CONTENT__REPLACEMENTS;

	/**
	 * The number of structural features of the '<em>Named Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Named Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl <em>Workflow</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getWorkflow()
	 * @generated
	 */
	int WORKFLOW = 1;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__CONTENT = NAMED_ELEMENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__REPLACEMENTS = NAMED_ELEMENT__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Is Runnable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__IS_RUNNABLE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__OPERATIONS = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Workflows</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__WORKFLOWS = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Dialogs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__DIALOGS = NAMED_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Views</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW__VIEWS = NAMED_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Workflow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Workflow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ViewImpl <em>View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ViewImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getView()
	 * @generated
	 */
	int VIEW = 2;

	/**
	 * The number of structural features of the '<em>View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIEW_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBTableViewImpl <em>DB Table View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBTableViewImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBTableView()
	 * @generated
	 */
	int DB_TABLE_VIEW = 3;

	/**
	 * The feature id for the '<em><b>Database</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW__DATABASE = VIEW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Table</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW__TABLE = VIEW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Queries</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW__QUERIES = VIEW_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Console</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW__CONSOLE = VIEW_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>DB Table View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW_FEATURE_COUNT = VIEW_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>DB Table View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_VIEW_OPERATION_COUNT = VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConsoleImpl <em>DB Console</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConsoleImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBConsole()
	 * @generated
	 */
	int DB_CONSOLE = 4;

	/**
	 * The feature id for the '<em><b>Port</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONSOLE__PORT = 0;

	/**
	 * The number of structural features of the '<em>DB Console</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONSOLE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>DB Console</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONSOLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConfigImpl <em>DB Config</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConfigImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBConfig()
	 * @generated
	 */
	int DB_CONFIG = 5;

	/**
	 * The feature id for the '<em><b>Jdbc Driver</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG__JDBC_DRIVER = 0;

	/**
	 * The feature id for the '<em><b>Db Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG__DB_URL = 1;

	/**
	 * The feature id for the '<em><b>Query</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG__QUERY = 2;

	/**
	 * The feature id for the '<em><b>User</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG__USER = 3;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG__PASSWORD = 4;

	/**
	 * The number of structural features of the '<em>DB Config</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>DB Config</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_CONFIG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QueryImpl <em>Query</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QueryImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getQuery()
	 * @generated
	 */
	int QUERY = 6;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY__CONTENT = CONTENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY__REPLACEMENTS = CONTENT__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY__NAME = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PreparedQueryImpl <em>Prepared Query</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PreparedQueryImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPreparedQuery()
	 * @generated
	 */
	int PREPARED_QUERY = 7;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPARED_QUERY__CONTENT = QUERY__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPARED_QUERY__REPLACEMENTS = QUERY__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPARED_QUERY__NAME = QUERY__NAME;

	/**
	 * The number of structural features of the '<em>Prepared Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPARED_QUERY_FEATURE_COUNT = QUERY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Prepared Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPARED_QUERY_OPERATION_COUNT = QUERY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OperationImpl <em>Operation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OperationImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOperation()
	 * @generated
	 */
	int OPERATION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__NAME = 0;

	/**
	 * The number of structural features of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PathImpl <em>Path</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PathImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPath()
	 * @generated
	 */
	int PATH = 10;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATH__CONTENT = CONTENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATH__REPLACEMENTS = CONTENT__REPLACEMENTS;

	/**
	 * The number of structural features of the '<em>Path</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATH_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Path</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATH_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MkdirImpl <em>Mkdir</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MkdirImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMkdir()
	 * @generated
	 */
	int MKDIR = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MKDIR__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Path</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MKDIR__PATH = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Names</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MKDIR__NAMES = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Mkdir</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MKDIR_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Mkdir</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MKDIR_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CopyImpl <em>Copy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CopyImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getCopy()
	 * @generated
	 */
	int COPY = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY__STYLE = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY__SOURCE = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY__DESTINATION = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Copy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Copy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COPY_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ZipImpl <em>Zip</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ZipImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getZip()
	 * @generated
	 */
	int ZIP = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP__NAME = COPY__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP__STYLE = COPY__STYLE;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP__SOURCE = COPY__SOURCE;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP__DESTINATION = COPY__DESTINATION;

	/**
	 * The number of structural features of the '<em>Zip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP_FEATURE_COUNT = COPY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Zip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIP_OPERATION_COUNT = COPY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MoveImpl <em>Move</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MoveImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMove()
	 * @generated
	 */
	int MOVE = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE__NAME = COPY__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE__STYLE = COPY__STYLE;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE__SOURCE = COPY__SOURCE;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE__DESTINATION = COPY__DESTINATION;

	/**
	 * The number of structural features of the '<em>Move</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE_FEATURE_COUNT = COPY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Move</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVE_OPERATION_COUNT = COPY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RenameImpl <em>Rename</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RenameImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getRename()
	 * @generated
	 */
	int RENAME = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME__NAME = COPY__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME__STYLE = COPY__STYLE;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME__SOURCE = COPY__SOURCE;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME__DESTINATION = COPY__DESTINATION;

	/**
	 * The number of structural features of the '<em>Rename</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME_FEATURE_COUNT = COPY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Rename</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENAME_OPERATION_COUNT = COPY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DeleteImpl <em>Delete</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DeleteImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDelete()
	 * @generated
	 */
	int DELETE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE__NAME = COPY__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE__STYLE = COPY__STYLE;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE__SOURCE = COPY__SOURCE;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE__DESTINATION = COPY__DESTINATION;

	/**
	 * The feature id for the '<em><b>Rekursiv</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE__REKURSIV = COPY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Delete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE_FEATURE_COUNT = COPY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Delete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE_OPERATION_COUNT = COPY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnCommitImpl <em>Svn Commit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnCommitImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSvnCommit()
	 * @generated
	 */
	int SVN_COMMIT = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_COMMIT__NAME = OPERATION__NAME;

	/**
	 * The number of structural features of the '<em>Svn Commit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_COMMIT_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Svn Commit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_COMMIT_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnUpdateImpl <em>Svn Update</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnUpdateImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSvnUpdate()
	 * @generated
	 */
	int SVN_UPDATE = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_UPDATE__NAME = OPERATION__NAME;

	/**
	 * The number of structural features of the '<em>Svn Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_UPDATE_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Svn Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SVN_UPDATE_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitCommitImpl <em>Git Commit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitCommitImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getGitCommit()
	 * @generated
	 */
	int GIT_COMMIT = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_COMMIT__NAME = OPERATION__NAME;

	/**
	 * The number of structural features of the '<em>Git Commit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_COMMIT_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Git Commit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_COMMIT_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitUpdateImpl <em>Git Update</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitUpdateImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getGitUpdate()
	 * @generated
	 */
	int GIT_UPDATE = 21;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_UPDATE__NAME = OPERATION__NAME;

	/**
	 * The number of structural features of the '<em>Git Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_UPDATE_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Git Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIT_UPDATE_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ServiceCheckImpl <em>Service Check</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ServiceCheckImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getServiceCheck()
	 * @generated
	 */
	int SERVICE_CHECK = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_CHECK__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Server</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_CHECK__SERVER = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Service Check</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_CHECK_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Service Check</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_CHECK_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RemoteDesktopImpl <em>Remote Desktop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RemoteDesktopImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getRemoteDesktop()
	 * @generated
	 */
	int REMOTE_DESKTOP = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Server</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP__SERVER = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>User</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP__USER = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP__PASSWORD = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Remote Desktop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Remote Desktop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOTE_DESKTOP_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.JavaImpl <em>Java</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.JavaImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getJava()
	 * @generated
	 */
	int JAVA = 24;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA__NAME = COPY__NAME;

	/**
	 * The feature id for the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA__STYLE = COPY__STYLE;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA__SOURCE = COPY__SOURCE;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA__DESTINATION = COPY__DESTINATION;

	/**
	 * The number of structural features of the '<em>Java</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FEATURE_COUNT = COPY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Java</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_OPERATION_COUNT = COPY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ExeImpl <em>Exe</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ExeImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getExe()
	 * @generated
	 */
	int EXE = 25;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXE__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Exe Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXE__EXE_TYPE = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Path</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXE__PATH = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Exe</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXE_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Exe</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXE_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SSMSImpl <em>SSMS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SSMSImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSSMS()
	 * @generated
	 */
	int SSMS = 26;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Server</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__SERVER = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Database</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__DATABASE = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>User</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__USER = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__PASSWORD = OPERATION_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>No Splash</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS__NO_SPLASH = OPERATION_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>SSMS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>SSMS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SSMS_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ClipboardImpl <em>Clipboard</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ClipboardImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getClipboard()
	 * @generated
	 */
	int CLIPBOARD = 27;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIPBOARD__NAME = OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIPBOARD__CONTENT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIPBOARD__REPLACEMENTS = OPERATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Clipboard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIPBOARD_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Clipboard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIPBOARD_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSeparatorImpl <em>String Separator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSeparatorImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringSeparator()
	 * @generated
	 */
	int STRING_SEPARATOR = 28;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR__NAME = CLIPBOARD__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR__CONTENT = CLIPBOARD__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR__REPLACEMENTS = CLIPBOARD__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Line Separator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR__LINE_SEPARATOR = CLIPBOARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>String Separator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR_FEATURE_COUNT = CLIPBOARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>String Separator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SEPARATOR_OPERATION_COUNT = CLIPBOARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSplitterImpl <em>String Splitter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSplitterImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringSplitter()
	 * @generated
	 */
	int STRING_SPLITTER = 29;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER__NAME = CLIPBOARD__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER__CONTENT = CLIPBOARD__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER__REPLACEMENTS = CLIPBOARD__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Split By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER__SPLIT_BY = CLIPBOARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>String Splitter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER_FEATURE_COUNT = CLIPBOARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>String Splitter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_SPLITTER_OPERATION_COUNT = CLIPBOARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringReplacerImpl <em>String Replacer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringReplacerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringReplacer()
	 * @generated
	 */
	int STRING_REPLACER = 30;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__NAME = CLIPBOARD__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__CONTENT = CLIPBOARD__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__REPLACEMENTS = CLIPBOARD__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Regex</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__REGEX = CLIPBOARD_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Replacer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__REPLACER = CLIPBOARD_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Replace All</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER__REPLACE_ALL = CLIPBOARD_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>String Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER_FEATURE_COUNT = CLIPBOARD_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>String Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_REPLACER_OPERATION_COUNT = CLIPBOARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToXlsImpl <em>String To Xls</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToXlsImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToXls()
	 * @generated
	 */
	int STRING_TO_XLS = 31;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_XLS__NAME = CLIPBOARD__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_XLS__CONTENT = CLIPBOARD__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_XLS__REPLACEMENTS = CLIPBOARD__REPLACEMENTS;

	/**
	 * The number of structural features of the '<em>String To Xls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_XLS_FEATURE_COUNT = CLIPBOARD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>String To Xls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_XLS_OPERATION_COUNT = CLIPBOARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToFileImpl <em>String To File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToFileImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToFile()
	 * @generated
	 */
	int STRING_TO_FILE = 32;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE__NAME = CLIPBOARD__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE__CONTENT = CLIPBOARD__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE__REPLACEMENTS = CLIPBOARD__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Extendsion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE__EXTENDSION = CLIPBOARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>String To File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE_FEATURE_COUNT = CLIPBOARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>String To File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_FILE_OPERATION_COUNT = CLIPBOARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QuestionDialogImpl <em>Question Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QuestionDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getQuestionDialog()
	 * @generated
	 */
	int QUESTION_DIALOG = 33;

	/**
	 * The number of structural features of the '<em>Question Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUESTION_DIALOG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Question Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUESTION_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InfoDialogImpl <em>Info Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InfoDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInfoDialog()
	 * @generated
	 */
	int INFO_DIALOG = 34;

	/**
	 * The number of structural features of the '<em>Info Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_DIALOG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Info Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MessageDialogImpl <em>Message Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MessageDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMessageDialog()
	 * @generated
	 */
	int MESSAGE_DIALOG = 35;

	/**
	 * The number of structural features of the '<em>Message Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_DIALOG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Message Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SelectionDialogImpl <em>Selection Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SelectionDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSelectionDialog()
	 * @generated
	 */
	int SELECTION_DIALOG = 36;

	/**
	 * The number of structural features of the '<em>Selection Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_DIALOG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Selection Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.FilteredDialogImpl <em>Filtered Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.FilteredDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getFilteredDialog()
	 * @generated
	 */
	int FILTERED_DIALOG = 37;

	/**
	 * The number of structural features of the '<em>Filtered Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERED_DIALOG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Filtered Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERED_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.EmailImpl <em>Email</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.EmailImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getEmail()
	 * @generated
	 */
	int EMAIL = 38;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL__CONTENT = CONTENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL__REPLACEMENTS = CONTENT__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Receiper</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL__RECEIPER = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Topic</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL__TOPIC = CONTENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl <em>Csv Table Parser</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getCsvTableParser()
	 * @generated
	 */
	int CSV_TABLE_PARSER = 39;

	/**
	 * The feature id for the '<em><b>File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER__FILE_PATH = VIEW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Start Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER__START_INDEX = VIEW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>End Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER__END_INDEX = VIEW_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Split By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER__SPLIT_BY = VIEW_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Csv Table Parser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER_FEATURE_COUNT = VIEW_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Csv Table Parser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CSV_TABLE_PARSER_OPERATION_COUNT = VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ChartImpl <em>Chart</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ChartImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getChart()
	 * @generated
	 */
	int CHART = 40;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART__TITLE = VIEW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>XTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART__XTITLE = VIEW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>YTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART__YTITLE = VIEW_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Points</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART__POINTS = VIEW_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART_FEATURE_COUNT = VIEW_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHART_OPERATION_COUNT = VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PointImpl <em>Point</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PointImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPoint()
	 * @generated
	 */
	int POINT = 41;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT__X = 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT__Y = 1;

	/**
	 * The number of structural features of the '<em>Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.LineChartImpl <em>Line Chart</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.LineChartImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getLineChart()
	 * @generated
	 */
	int LINE_CHART = 42;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART__TITLE = CHART__TITLE;

	/**
	 * The feature id for the '<em><b>XTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART__XTITLE = CHART__XTITLE;

	/**
	 * The feature id for the '<em><b>YTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART__YTITLE = CHART__YTITLE;

	/**
	 * The feature id for the '<em><b>Points</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART__POINTS = CHART__POINTS;

	/**
	 * The number of structural features of the '<em>Line Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART_FEATURE_COUNT = CHART_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Line Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_CHART_OPERATION_COUNT = CHART_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.BarChartImpl <em>Bar Chart</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.BarChartImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getBarChart()
	 * @generated
	 */
	int BAR_CHART = 43;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART__TITLE = CHART__TITLE;

	/**
	 * The feature id for the '<em><b>XTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART__XTITLE = CHART__XTITLE;

	/**
	 * The feature id for the '<em><b>YTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART__YTITLE = CHART__YTITLE;

	/**
	 * The feature id for the '<em><b>Points</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART__POINTS = CHART__POINTS;

	/**
	 * The number of structural features of the '<em>Bar Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART_FEATURE_COUNT = CHART_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Bar Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BAR_CHART_OPERATION_COUNT = CHART_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ScatterChartImpl <em>Scatter Chart</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ScatterChartImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getScatterChart()
	 * @generated
	 */
	int SCATTER_CHART = 44;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART__TITLE = CHART__TITLE;

	/**
	 * The feature id for the '<em><b>XTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART__XTITLE = CHART__XTITLE;

	/**
	 * The feature id for the '<em><b>YTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART__YTITLE = CHART__YTITLE;

	/**
	 * The feature id for the '<em><b>Points</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART__POINTS = CHART__POINTS;

	/**
	 * The number of structural features of the '<em>Scatter Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART_FEATURE_COUNT = CHART_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Scatter Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCATTER_CHART_OPERATION_COUNT = CHART_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PieChartImpl <em>Pie Chart</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PieChartImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPieChart()
	 * @generated
	 */
	int PIE_CHART = 45;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART__TITLE = CHART__TITLE;

	/**
	 * The feature id for the '<em><b>XTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART__XTITLE = CHART__XTITLE;

	/**
	 * The feature id for the '<em><b>YTitle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART__YTITLE = CHART__YTITLE;

	/**
	 * The feature id for the '<em><b>Points</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART__POINTS = CHART__POINTS;

	/**
	 * The number of structural features of the '<em>Pie Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART_FEATURE_COUNT = CHART_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Pie Chart</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIE_CHART_OPERATION_COUNT = CHART_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToListImpl <em>String To List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToListImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToList()
	 * @generated
	 */
	int STRING_TO_LIST = 46;

	/**
	 * The feature id for the '<em><b>Sorter</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_LIST__SORTER = 0;

	/**
	 * The feature id for the '<em><b>List</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_LIST__LIST = 1;

	/**
	 * The number of structural features of the '<em>String To List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_LIST_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>String To List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_TO_LIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SorterImpl <em>Sorter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SorterImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSorter()
	 * @generated
	 */
	int SORTER = 47;

	/**
	 * The feature id for the '<em><b>Is Asc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SORTER__IS_ASC = 0;

	/**
	 * The number of structural features of the '<em>Sorter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SORTER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Sorter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SORTER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListImpl <em>List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getList()
	 * @generated
	 */
	int LIST = 48;

	/**
	 * The feature id for the '<em><b>Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__ITEMS = 0;

	/**
	 * The number of structural features of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ItemImpl <em>Item</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ItemImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getItem()
	 * @generated
	 */
	int ITEM = 49;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacementImpl <em>Replacement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacementImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getReplacement()
	 * @generated
	 */
	int REPLACEMENT = 50;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACEMENT__VARIABLE = 0;

	/**
	 * The feature id for the '<em><b>Replacer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACEMENT__REPLACER = 1;

	/**
	 * The number of structural features of the '<em>Replacement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACEMENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Replacement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacerImpl <em>Replacer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getReplacer()
	 * @generated
	 */
	int REPLACER = 51;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACER__VALUE = 0;

	/**
	 * The number of structural features of the '<em>Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLACER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionReplacerImpl <em>Option Replacer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionReplacerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOptionReplacer()
	 * @generated
	 */
	int OPTION_REPLACER = 52;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_REPLACER__VALUE = REPLACER__VALUE;

	/**
	 * The feature id for the '<em><b>Options</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_REPLACER__OPTIONS = REPLACER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Option Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_REPLACER_FEATURE_COUNT = REPLACER_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Option Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_REPLACER_OPERATION_COUNT = REPLACER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionImpl <em>Option</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOption()
	 * @generated
	 */
	int OPTION = 53;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Option</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Option</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputReplacerImpl <em>Input Replacer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputReplacerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInputReplacer()
	 * @generated
	 */
	int INPUT_REPLACER = 54;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_REPLACER__VALUE = REPLACER__VALUE;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_REPLACER__TITLE = REPLACER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_REPLACER__MESSAGE = REPLACER_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Input Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_REPLACER_FEATURE_COUNT = REPLACER_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Input Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_REPLACER_OPERATION_COUNT = REPLACER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TimestampReplacerImpl <em>Timestamp Replacer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TimestampReplacerImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getTimestampReplacer()
	 * @generated
	 */
	int TIMESTAMP_REPLACER = 55;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMESTAMP_REPLACER__VALUE = REPLACER__VALUE;

	/**
	 * The feature id for the '<em><b>Formatter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMESTAMP_REPLACER__FORMATTER = REPLACER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Timestamp Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMESTAMP_REPLACER_FEATURE_COUNT = REPLACER_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Timestamp Replacer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMESTAMP_REPLACER_OPERATION_COUNT = REPLACER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputDialogImpl <em>Input Dialog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputDialogImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInputDialog()
	 * @generated
	 */
	int INPUT_DIALOG = 56;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__TITLE = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__HEIGHT = 2;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__WIDTH = 3;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__CONTENT = 4;

	/**
	 * The feature id for the '<em><b>Use Template</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__USE_TEMPLATE = 5;

	/**
	 * The feature id for the '<em><b>Template Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__TEMPLATE_NAME = 6;

	/**
	 * The feature id for the '<em><b>Controls</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__CONTROLS = 7;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG__OPERATIONS = 8;

	/**
	 * The number of structural features of the '<em>Input Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Input Dialog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DIALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ControlImpl <em>Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ControlImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getControl()
	 * @generated
	 */
	int CONTROL = 62;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL__CONTENT = NAMED_ELEMENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL__REPLACEMENTS = NAMED_ELEMENT__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL__VARIABLE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL__VALUE = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TextControlImpl <em>Text Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TextControlImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getTextControl()
	 * @generated
	 */
	int TEXT_CONTROL = 57;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL__CONTENT = CONTROL__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL__REPLACEMENTS = CONTROL__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL__VARIABLE = CONTROL__VARIABLE;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL__VALUE = CONTROL__VALUE;

	/**
	 * The number of structural features of the '<em>Text Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL_FEATURE_COUNT = CONTROL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Text Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_CONTROL_OPERATION_COUNT = CONTROL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DateControlImpl <em>Date Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DateControlImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDateControl()
	 * @generated
	 */
	int DATE_CONTROL = 58;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL__CONTENT = TEXT_CONTROL__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL__REPLACEMENTS = TEXT_CONTROL__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL__VARIABLE = TEXT_CONTROL__VARIABLE;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL__VALUE = TEXT_CONTROL__VALUE;

	/**
	 * The feature id for the '<em><b>Formatter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL__FORMATTER = TEXT_CONTROL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Date Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL_FEATURE_COUNT = TEXT_CONTROL_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Date Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_CONTROL_OPERATION_COUNT = TEXT_CONTROL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListControlImpl <em>List Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListControlImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getListControl()
	 * @generated
	 */
	int LIST_CONTROL = 59;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL__CONTENT = CONTROL__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL__REPLACEMENTS = CONTROL__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL__VARIABLE = CONTROL__VARIABLE;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL__VALUE = CONTROL__VALUE;

	/**
	 * The feature id for the '<em><b>Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL__ITEMS = CONTROL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>List Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL_FEATURE_COUNT = CONTROL_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>List Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_CONTROL_OPERATION_COUNT = CONTROL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboControlImpl <em>Combo Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboControlImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getComboControl()
	 * @generated
	 */
	int COMBO_CONTROL = 60;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL__CONTENT = CONTROL__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL__REPLACEMENTS = CONTROL__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL__VARIABLE = CONTROL__VARIABLE;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL__VALUE = CONTROL__VALUE;

	/**
	 * The feature id for the '<em><b>Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL__ITEMS = CONTROL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Combo Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL_FEATURE_COUNT = CONTROL_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Combo Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_CONTROL_OPERATION_COUNT = CONTROL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboItemImpl <em>Combo Item</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboItemImpl
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getComboItem()
	 * @generated
	 */
	int COMBO_ITEM = 61;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_ITEM__CONTENT = CONTENT__CONTENT;

	/**
	 * The feature id for the '<em><b>Replacements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_ITEM__REPLACEMENTS = CONTENT__REPLACEMENTS;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_ITEM__VALUE = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Combo Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_ITEM_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Combo Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBO_ITEM_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle <em>Form Style</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getFormStyle()
	 * @generated
	 */
	int FORM_STYLE = 63;

	/**
	 * The meta object id for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType <em>Exe Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getExeType()
	 * @generated
	 */
	int EXE_TYPE = 64;

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Manager</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager
	 * @generated
	 */
	EClass getWorkflowManager();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager#getWorkflows <em>Workflows</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Workflows</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager#getWorkflows()
	 * @see #getWorkflowManager()
	 * @generated
	 */
	EReference getWorkflowManager_Workflows();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Workflow</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow
	 * @generated
	 */
	EClass getWorkflow();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#isIsRunnable <em>Is Runnable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Runnable</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#isIsRunnable()
	 * @see #getWorkflow()
	 * @generated
	 */
	EAttribute getWorkflow_IsRunnable();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getOperations()
	 * @see #getWorkflow()
	 * @generated
	 */
	EReference getWorkflow_Operations();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getWorkflows <em>Workflows</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Workflows</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getWorkflows()
	 * @see #getWorkflow()
	 * @generated
	 */
	EReference getWorkflow_Workflows();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getDialogs <em>Dialogs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dialogs</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getDialogs()
	 * @see #getWorkflow()
	 * @generated
	 */
	EReference getWorkflow_Dialogs();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getViews <em>Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Views</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow#getViews()
	 * @see #getWorkflow()
	 * @generated
	 */
	EReference getWorkflow_Views();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.View <em>View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>View</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.View
	 * @generated
	 */
	EClass getView();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView <em>DB Table View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Table View</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView
	 * @generated
	 */
	EClass getDBTableView();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getDatabase <em>Database</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Database</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getDatabase()
	 * @see #getDBTableView()
	 * @generated
	 */
	EReference getDBTableView_Database();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getTable <em>Table</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Table</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getTable()
	 * @see #getDBTableView()
	 * @generated
	 */
	EAttribute getDBTableView_Table();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getQueries <em>Queries</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Queries</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getQueries()
	 * @see #getDBTableView()
	 * @generated
	 */
	EReference getDBTableView_Queries();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getConsole <em>Console</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Console</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getConsole()
	 * @see #getDBTableView()
	 * @generated
	 */
	EReference getDBTableView_Console();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole <em>DB Console</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Console</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole
	 * @generated
	 */
	EClass getDBConsole();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole#getPort <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Port</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole#getPort()
	 * @see #getDBConsole()
	 * @generated
	 */
	EAttribute getDBConsole_Port();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig <em>DB Config</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Config</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig
	 * @generated
	 */
	EClass getDBConfig();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getJdbcDriver <em>Jdbc Driver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Jdbc Driver</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getJdbcDriver()
	 * @see #getDBConfig()
	 * @generated
	 */
	EAttribute getDBConfig_JdbcDriver();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getDbUrl <em>Db Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Db Url</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getDbUrl()
	 * @see #getDBConfig()
	 * @generated
	 */
	EAttribute getDBConfig_DbUrl();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getQuery <em>Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Query</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getQuery()
	 * @see #getDBConfig()
	 * @generated
	 */
	EAttribute getDBConfig_Query();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>User</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getUser()
	 * @see #getDBConfig()
	 * @generated
	 */
	EAttribute getDBConfig_User();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig#getPassword()
	 * @see #getDBConfig()
	 * @generated
	 */
	EAttribute getDBConfig_Password();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Query <em>Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Query</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Query
	 * @generated
	 */
	EClass getQuery();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Query#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Query#getName()
	 * @see #getQuery()
	 * @generated
	 */
	EAttribute getQuery_Name();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.PreparedQuery <em>Prepared Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Prepared Query</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.PreparedQuery
	 * @generated
	 */
	EClass getPreparedQuery();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operation</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation
	 * @generated
	 */
	EClass getOperation();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation#getName()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_Name();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Content <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Content</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Content
	 * @generated
	 */
	EClass getContent();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Content#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Content#getContent()
	 * @see #getContent()
	 * @generated
	 */
	EAttribute getContent_Content();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Content#getReplacements <em>Replacements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Replacements</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Content#getReplacements()
	 * @see #getContent()
	 * @generated
	 */
	EReference getContent_Replacements();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Path <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Path</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Path
	 * @generated
	 */
	EClass getPath();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.NamedElement <em>Named Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Named Element</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.NamedElement
	 * @generated
	 */
	EClass getNamedElement();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir <em>Mkdir</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mkdir</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir
	 * @generated
	 */
	EClass getMkdir();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Path</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getPath()
	 * @see #getMkdir()
	 * @generated
	 */
	EReference getMkdir_Path();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getNames <em>Names</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Names</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getNames()
	 * @see #getMkdir()
	 * @generated
	 */
	EReference getMkdir_Names();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy <em>Copy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Copy</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy
	 * @generated
	 */
	EClass getCopy();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getStyle <em>Style</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Style</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getStyle()
	 * @see #getCopy()
	 * @generated
	 */
	EAttribute getCopy_Style();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Source</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getSource()
	 * @see #getCopy()
	 * @generated
	 */
	EReference getCopy_Source();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getDestination <em>Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Destination</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy#getDestination()
	 * @see #getCopy()
	 * @generated
	 */
	EReference getCopy_Destination();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Zip <em>Zip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Zip</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Zip
	 * @generated
	 */
	EClass getZip();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Move <em>Move</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Move</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Move
	 * @generated
	 */
	EClass getMove();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Rename <em>Rename</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rename</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Rename
	 * @generated
	 */
	EClass getRename();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete <em>Delete</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Delete</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete
	 * @generated
	 */
	EClass getDelete();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete#isRekursiv <em>Rekursiv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rekursiv</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete#isRekursiv()
	 * @see #getDelete()
	 * @generated
	 */
	EAttribute getDelete_Rekursiv();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnCommit <em>Svn Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Svn Commit</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnCommit
	 * @generated
	 */
	EClass getSvnCommit();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnUpdate <em>Svn Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Svn Update</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnUpdate
	 * @generated
	 */
	EClass getSvnUpdate();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.GitCommit <em>Git Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Git Commit</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.GitCommit
	 * @generated
	 */
	EClass getGitCommit();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.GitUpdate <em>Git Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Git Update</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.GitUpdate
	 * @generated
	 */
	EClass getGitUpdate();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck <em>Service Check</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Check</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck
	 * @generated
	 */
	EClass getServiceCheck();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck#getServer <em>Server</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Server</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck#getServer()
	 * @see #getServiceCheck()
	 * @generated
	 */
	EAttribute getServiceCheck_Server();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop <em>Remote Desktop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remote Desktop</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop
	 * @generated
	 */
	EClass getRemoteDesktop();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getServer <em>Server</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Server</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getServer()
	 * @see #getRemoteDesktop()
	 * @generated
	 */
	EAttribute getRemoteDesktop_Server();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>User</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getUser()
	 * @see #getRemoteDesktop()
	 * @generated
	 */
	EAttribute getRemoteDesktop_User();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop#getPassword()
	 * @see #getRemoteDesktop()
	 * @generated
	 */
	EAttribute getRemoteDesktop_Password();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Java <em>Java</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Java
	 * @generated
	 */
	EClass getJava();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe <em>Exe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Exe</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe
	 * @generated
	 */
	EClass getExe();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe#getExeType <em>Exe Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Exe Type</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe#getExeType()
	 * @see #getExe()
	 * @generated
	 */
	EAttribute getExe_ExeType();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Path</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe#getPath()
	 * @see #getExe()
	 * @generated
	 */
	EReference getExe_Path();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS <em>SSMS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SSMS</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS
	 * @generated
	 */
	EClass getSSMS();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getServer <em>Server</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Server</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getServer()
	 * @see #getSSMS()
	 * @generated
	 */
	EAttribute getSSMS_Server();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getDatabase <em>Database</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Database</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getDatabase()
	 * @see #getSSMS()
	 * @generated
	 */
	EAttribute getSSMS_Database();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>User</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getUser()
	 * @see #getSSMS()
	 * @generated
	 */
	EAttribute getSSMS_User();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#getPassword()
	 * @see #getSSMS()
	 * @generated
	 */
	EAttribute getSSMS_Password();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#isNoSplash <em>No Splash</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>No Splash</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS#isNoSplash()
	 * @see #getSSMS()
	 * @generated
	 */
	EAttribute getSSMS_NoSplash();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard <em>Clipboard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clipboard</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard
	 * @generated
	 */
	EClass getClipboard();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator <em>String Separator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String Separator</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator
	 * @generated
	 */
	EClass getStringSeparator();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator#getLineSeparator <em>Line Separator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Line Separator</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator#getLineSeparator()
	 * @see #getStringSeparator()
	 * @generated
	 */
	EAttribute getStringSeparator_LineSeparator();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter <em>String Splitter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String Splitter</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter
	 * @generated
	 */
	EClass getStringSplitter();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter#getSplitBy <em>Split By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Split By</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter#getSplitBy()
	 * @see #getStringSplitter()
	 * @generated
	 */
	EAttribute getStringSplitter_SplitBy();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer <em>String Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer
	 * @generated
	 */
	EClass getStringReplacer();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#getRegex <em>Regex</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Regex</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#getRegex()
	 * @see #getStringReplacer()
	 * @generated
	 */
	EAttribute getStringReplacer_Regex();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#getReplacer <em>Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#getReplacer()
	 * @see #getStringReplacer()
	 * @generated
	 */
	EAttribute getStringReplacer_Replacer();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#isReplaceAll <em>Replace All</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Replace All</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer#isReplaceAll()
	 * @see #getStringReplacer()
	 * @generated
	 */
	EAttribute getStringReplacer_ReplaceAll();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToXls <em>String To Xls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String To Xls</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToXls
	 * @generated
	 */
	EClass getStringToXls();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile <em>String To File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String To File</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile
	 * @generated
	 */
	EClass getStringToFile();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile#getExtendsion <em>Extendsion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Extendsion</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile#getExtendsion()
	 * @see #getStringToFile()
	 * @generated
	 */
	EAttribute getStringToFile_Extendsion();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.QuestionDialog <em>Question Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Question Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.QuestionDialog
	 * @generated
	 */
	EClass getQuestionDialog();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InfoDialog <em>Info Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Info Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InfoDialog
	 * @generated
	 */
	EClass getInfoDialog();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.MessageDialog <em>Message Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Message Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.MessageDialog
	 * @generated
	 */
	EClass getMessageDialog();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SelectionDialog <em>Selection Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Selection Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SelectionDialog
	 * @generated
	 */
	EClass getSelectionDialog();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FilteredDialog <em>Filtered Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Filtered Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FilteredDialog
	 * @generated
	 */
	EClass getFilteredDialog();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Email <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Email</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Email
	 * @generated
	 */
	EClass getEmail();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Email#getReceiper <em>Receiper</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Receiper</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Email#getReceiper()
	 * @see #getEmail()
	 * @generated
	 */
	EAttribute getEmail_Receiper();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Email#getTopic <em>Topic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Topic</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Email#getTopic()
	 * @see #getEmail()
	 * @generated
	 */
	EAttribute getEmail_Topic();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser <em>Csv Table Parser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Csv Table Parser</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser
	 * @generated
	 */
	EClass getCsvTableParser();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getFilePath <em>File Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Path</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getFilePath()
	 * @see #getCsvTableParser()
	 * @generated
	 */
	EAttribute getCsvTableParser_FilePath();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getStartIndex <em>Start Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start Index</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getStartIndex()
	 * @see #getCsvTableParser()
	 * @generated
	 */
	EAttribute getCsvTableParser_StartIndex();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getEndIndex <em>End Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End Index</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getEndIndex()
	 * @see #getCsvTableParser()
	 * @generated
	 */
	EAttribute getCsvTableParser_EndIndex();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getSplitBy <em>Split By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Split By</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser#getSplitBy()
	 * @see #getCsvTableParser()
	 * @generated
	 */
	EAttribute getCsvTableParser_SplitBy();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart <em>Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Chart</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart
	 * @generated
	 */
	EClass getChart();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getTitle()
	 * @see #getChart()
	 * @generated
	 */
	EAttribute getChart_Title();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getXTitle <em>XTitle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>XTitle</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getXTitle()
	 * @see #getChart()
	 * @generated
	 */
	EAttribute getChart_XTitle();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getYTitle <em>YTitle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>YTitle</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getYTitle()
	 * @see #getChart()
	 * @generated
	 */
	EAttribute getChart_YTitle();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getPoints <em>Points</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Points</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart#getPoints()
	 * @see #getChart()
	 * @generated
	 */
	EReference getChart_Points();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Point <em>Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Point</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Point
	 * @generated
	 */
	EClass getPoint();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Point#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Point#getX()
	 * @see #getPoint()
	 * @generated
	 */
	EAttribute getPoint_X();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Point#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Point#getY()
	 * @see #getPoint()
	 * @generated
	 */
	EAttribute getPoint_Y();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.LineChart <em>Line Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Line Chart</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.LineChart
	 * @generated
	 */
	EClass getLineChart();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.BarChart <em>Bar Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bar Chart</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.BarChart
	 * @generated
	 */
	EClass getBarChart();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ScatterChart <em>Scatter Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scatter Chart</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ScatterChart
	 * @generated
	 */
	EClass getScatterChart();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.PieChart <em>Pie Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pie Chart</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.PieChart
	 * @generated
	 */
	EClass getPieChart();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList <em>String To List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String To List</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList
	 * @generated
	 */
	EClass getStringToList();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList#getSorter <em>Sorter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sorter</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList#getSorter()
	 * @see #getStringToList()
	 * @generated
	 */
	EReference getStringToList_Sorter();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList#getList <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>List</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList#getList()
	 * @see #getStringToList()
	 * @generated
	 */
	EReference getStringToList_List();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter <em>Sorter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sorter</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter
	 * @generated
	 */
	EClass getSorter();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter#isIsAsc <em>Is Asc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Asc</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter#isIsAsc()
	 * @see #getSorter()
	 * @generated
	 */
	EAttribute getSorter_IsAsc();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>List</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.List
	 * @generated
	 */
	EClass getList();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.List#getItems <em>Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Items</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.List#getItems()
	 * @see #getList()
	 * @generated
	 */
	EReference getList_Items();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Item <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Item</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Item
	 * @generated
	 */
	EClass getItem();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Item#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Item#getName()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_Name();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Item#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Item#getValue()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_Value();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement <em>Replacement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Replacement</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement
	 * @generated
	 */
	EClass getReplacement();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getVariable <em>Variable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Variable</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getVariable()
	 * @see #getReplacement()
	 * @generated
	 */
	EAttribute getReplacement_Variable();

	/**
	 * Returns the meta object for the containment reference '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getReplacer <em>Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement#getReplacer()
	 * @see #getReplacement()
	 * @generated
	 */
	EReference getReplacement_Replacer();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer <em>Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer
	 * @generated
	 */
	EClass getReplacer();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer#getValue()
	 * @see #getReplacer()
	 * @generated
	 */
	EAttribute getReplacer_Value();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer <em>Option Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Option Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer
	 * @generated
	 */
	EClass getOptionReplacer();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer#getOptions <em>Options</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Options</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer#getOptions()
	 * @see #getOptionReplacer()
	 * @generated
	 */
	EReference getOptionReplacer_Options();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Option <em>Option</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Option</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Option
	 * @generated
	 */
	EClass getOption();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Option#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Option#getName()
	 * @see #getOption()
	 * @generated
	 */
	EAttribute getOption_Name();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Option#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Option#getValue()
	 * @see #getOption()
	 * @generated
	 */
	EAttribute getOption_Value();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer <em>Input Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer
	 * @generated
	 */
	EClass getInputReplacer();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getTitle()
	 * @see #getInputReplacer()
	 * @generated
	 */
	EAttribute getInputReplacer_Title();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Message</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer#getMessage()
	 * @see #getInputReplacer()
	 * @generated
	 */
	EAttribute getInputReplacer_Message();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer <em>Timestamp Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Timestamp Replacer</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer
	 * @generated
	 */
	EClass getTimestampReplacer();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer#getFormatter <em>Formatter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Formatter</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer#getFormatter()
	 * @see #getTimestampReplacer()
	 * @generated
	 */
	EAttribute getTimestampReplacer_Formatter();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog <em>Input Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Dialog</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog
	 * @generated
	 */
	EClass getInputDialog();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTitle()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_Title();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getDescription()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_Description();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getHeight()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_Height();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getWidth <em>Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Width</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getWidth()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_Width();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getContent()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_Content();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#isUseTemplate <em>Use Template</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Use Template</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#isUseTemplate()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_UseTemplate();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTemplateName <em>Template Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Template Name</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTemplateName()
	 * @see #getInputDialog()
	 * @generated
	 */
	EAttribute getInputDialog_TemplateName();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getControls <em>Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Controls</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getControls()
	 * @see #getInputDialog()
	 * @generated
	 */
	EReference getInputDialog_Controls();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getOperations()
	 * @see #getInputDialog()
	 * @generated
	 */
	EReference getInputDialog_Operations();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.TextControl <em>Text Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text Control</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.TextControl
	 * @generated
	 */
	EClass getTextControl();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl <em>Date Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Date Control</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl
	 * @generated
	 */
	EClass getDateControl();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl#getFormatter <em>Formatter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Formatter</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl#getFormatter()
	 * @see #getDateControl()
	 * @generated
	 */
	EAttribute getDateControl_Formatter();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl <em>List Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>List Control</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl
	 * @generated
	 */
	EClass getListControl();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl#getItems <em>Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Items</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl#getItems()
	 * @see #getListControl()
	 * @generated
	 */
	EReference getListControl_Items();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl <em>Combo Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Combo Control</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl
	 * @generated
	 */
	EClass getComboControl();

	/**
	 * Returns the meta object for the containment reference list '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl#getItems <em>Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Items</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl#getItems()
	 * @see #getComboControl()
	 * @generated
	 */
	EReference getComboControl_Items();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem <em>Combo Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Combo Item</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem
	 * @generated
	 */
	EClass getComboItem();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem#getValue()
	 * @see #getComboItem()
	 * @generated
	 */
	EAttribute getComboItem_Value();

	/**
	 * Returns the meta object for class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control <em>Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Control</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Control
	 * @generated
	 */
	EClass getControl();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getVariable <em>Variable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Variable</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getVariable()
	 * @see #getControl()
	 * @generated
	 */
	EAttribute getControl_Variable();

	/**
	 * Returns the meta object for the attribute '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getValue()
	 * @see #getControl()
	 * @generated
	 */
	EAttribute getControl_Value();

	/**
	 * Returns the meta object for enum '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle <em>Form Style</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Form Style</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle
	 * @generated
	 */
	EEnum getFormStyle();

	/**
	 * Returns the meta object for enum '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType <em>Exe Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Exe Type</em>'.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType
	 * @generated
	 */
	EEnum getExeType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	WorkflowFactory getWorkflowFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowManagerImpl <em>Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowManagerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getWorkflowManager()
		 * @generated
		 */
		EClass WORKFLOW_MANAGER = eINSTANCE.getWorkflowManager();

		/**
		 * The meta object literal for the '<em><b>Workflows</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WORKFLOW_MANAGER__WORKFLOWS = eINSTANCE.getWorkflowManager_Workflows();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl <em>Workflow</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getWorkflow()
		 * @generated
		 */
		EClass WORKFLOW = eINSTANCE.getWorkflow();

		/**
		 * The meta object literal for the '<em><b>Is Runnable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WORKFLOW__IS_RUNNABLE = eINSTANCE.getWorkflow_IsRunnable();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WORKFLOW__OPERATIONS = eINSTANCE.getWorkflow_Operations();

		/**
		 * The meta object literal for the '<em><b>Workflows</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WORKFLOW__WORKFLOWS = eINSTANCE.getWorkflow_Workflows();

		/**
		 * The meta object literal for the '<em><b>Dialogs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WORKFLOW__DIALOGS = eINSTANCE.getWorkflow_Dialogs();

		/**
		 * The meta object literal for the '<em><b>Views</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WORKFLOW__VIEWS = eINSTANCE.getWorkflow_Views();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ViewImpl <em>View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ViewImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getView()
		 * @generated
		 */
		EClass VIEW = eINSTANCE.getView();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBTableViewImpl <em>DB Table View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBTableViewImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBTableView()
		 * @generated
		 */
		EClass DB_TABLE_VIEW = eINSTANCE.getDBTableView();

		/**
		 * The meta object literal for the '<em><b>Database</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DB_TABLE_VIEW__DATABASE = eINSTANCE.getDBTableView_Database();

		/**
		 * The meta object literal for the '<em><b>Table</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_TABLE_VIEW__TABLE = eINSTANCE.getDBTableView_Table();

		/**
		 * The meta object literal for the '<em><b>Queries</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DB_TABLE_VIEW__QUERIES = eINSTANCE.getDBTableView_Queries();

		/**
		 * The meta object literal for the '<em><b>Console</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DB_TABLE_VIEW__CONSOLE = eINSTANCE.getDBTableView_Console();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConsoleImpl <em>DB Console</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConsoleImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBConsole()
		 * @generated
		 */
		EClass DB_CONSOLE = eINSTANCE.getDBConsole();

		/**
		 * The meta object literal for the '<em><b>Port</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONSOLE__PORT = eINSTANCE.getDBConsole_Port();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConfigImpl <em>DB Config</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DBConfigImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDBConfig()
		 * @generated
		 */
		EClass DB_CONFIG = eINSTANCE.getDBConfig();

		/**
		 * The meta object literal for the '<em><b>Jdbc Driver</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONFIG__JDBC_DRIVER = eINSTANCE.getDBConfig_JdbcDriver();

		/**
		 * The meta object literal for the '<em><b>Db Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONFIG__DB_URL = eINSTANCE.getDBConfig_DbUrl();

		/**
		 * The meta object literal for the '<em><b>Query</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONFIG__QUERY = eINSTANCE.getDBConfig_Query();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONFIG__USER = eINSTANCE.getDBConfig_User();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_CONFIG__PASSWORD = eINSTANCE.getDBConfig_Password();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QueryImpl <em>Query</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QueryImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getQuery()
		 * @generated
		 */
		EClass QUERY = eINSTANCE.getQuery();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute QUERY__NAME = eINSTANCE.getQuery_Name();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PreparedQueryImpl <em>Prepared Query</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PreparedQueryImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPreparedQuery()
		 * @generated
		 */
		EClass PREPARED_QUERY = eINSTANCE.getPreparedQuery();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OperationImpl <em>Operation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OperationImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOperation()
		 * @generated
		 */
		EClass OPERATION = eINSTANCE.getOperation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__NAME = eINSTANCE.getOperation_Name();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ContentImpl <em>Content</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ContentImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getContent()
		 * @generated
		 */
		EClass CONTENT = eINSTANCE.getContent();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTENT__CONTENT = eINSTANCE.getContent_Content();

		/**
		 * The meta object literal for the '<em><b>Replacements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTENT__REPLACEMENTS = eINSTANCE.getContent_Replacements();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PathImpl <em>Path</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PathImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPath()
		 * @generated
		 */
		EClass PATH = eINSTANCE.getPath();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.NamedElementImpl <em>Named Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.NamedElementImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getNamedElement()
		 * @generated
		 */
		EClass NAMED_ELEMENT = eINSTANCE.getNamedElement();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MkdirImpl <em>Mkdir</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MkdirImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMkdir()
		 * @generated
		 */
		EClass MKDIR = eINSTANCE.getMkdir();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MKDIR__PATH = eINSTANCE.getMkdir_Path();

		/**
		 * The meta object literal for the '<em><b>Names</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MKDIR__NAMES = eINSTANCE.getMkdir_Names();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CopyImpl <em>Copy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CopyImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getCopy()
		 * @generated
		 */
		EClass COPY = eINSTANCE.getCopy();

		/**
		 * The meta object literal for the '<em><b>Style</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COPY__STYLE = eINSTANCE.getCopy_Style();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COPY__SOURCE = eINSTANCE.getCopy_Source();

		/**
		 * The meta object literal for the '<em><b>Destination</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COPY__DESTINATION = eINSTANCE.getCopy_Destination();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ZipImpl <em>Zip</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ZipImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getZip()
		 * @generated
		 */
		EClass ZIP = eINSTANCE.getZip();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MoveImpl <em>Move</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MoveImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMove()
		 * @generated
		 */
		EClass MOVE = eINSTANCE.getMove();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RenameImpl <em>Rename</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RenameImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getRename()
		 * @generated
		 */
		EClass RENAME = eINSTANCE.getRename();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DeleteImpl <em>Delete</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DeleteImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDelete()
		 * @generated
		 */
		EClass DELETE = eINSTANCE.getDelete();

		/**
		 * The meta object literal for the '<em><b>Rekursiv</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELETE__REKURSIV = eINSTANCE.getDelete_Rekursiv();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnCommitImpl <em>Svn Commit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnCommitImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSvnCommit()
		 * @generated
		 */
		EClass SVN_COMMIT = eINSTANCE.getSvnCommit();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnUpdateImpl <em>Svn Update</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SvnUpdateImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSvnUpdate()
		 * @generated
		 */
		EClass SVN_UPDATE = eINSTANCE.getSvnUpdate();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitCommitImpl <em>Git Commit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitCommitImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getGitCommit()
		 * @generated
		 */
		EClass GIT_COMMIT = eINSTANCE.getGitCommit();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitUpdateImpl <em>Git Update</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.GitUpdateImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getGitUpdate()
		 * @generated
		 */
		EClass GIT_UPDATE = eINSTANCE.getGitUpdate();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ServiceCheckImpl <em>Service Check</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ServiceCheckImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getServiceCheck()
		 * @generated
		 */
		EClass SERVICE_CHECK = eINSTANCE.getServiceCheck();

		/**
		 * The meta object literal for the '<em><b>Server</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_CHECK__SERVER = eINSTANCE.getServiceCheck_Server();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RemoteDesktopImpl <em>Remote Desktop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.RemoteDesktopImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getRemoteDesktop()
		 * @generated
		 */
		EClass REMOTE_DESKTOP = eINSTANCE.getRemoteDesktop();

		/**
		 * The meta object literal for the '<em><b>Server</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOTE_DESKTOP__SERVER = eINSTANCE.getRemoteDesktop_Server();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOTE_DESKTOP__USER = eINSTANCE.getRemoteDesktop_User();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOTE_DESKTOP__PASSWORD = eINSTANCE.getRemoteDesktop_Password();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.JavaImpl <em>Java</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.JavaImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getJava()
		 * @generated
		 */
		EClass JAVA = eINSTANCE.getJava();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ExeImpl <em>Exe</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ExeImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getExe()
		 * @generated
		 */
		EClass EXE = eINSTANCE.getExe();

		/**
		 * The meta object literal for the '<em><b>Exe Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXE__EXE_TYPE = eINSTANCE.getExe_ExeType();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXE__PATH = eINSTANCE.getExe_Path();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SSMSImpl <em>SSMS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SSMSImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSSMS()
		 * @generated
		 */
		EClass SSMS = eINSTANCE.getSSMS();

		/**
		 * The meta object literal for the '<em><b>Server</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SSMS__SERVER = eINSTANCE.getSSMS_Server();

		/**
		 * The meta object literal for the '<em><b>Database</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SSMS__DATABASE = eINSTANCE.getSSMS_Database();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SSMS__USER = eINSTANCE.getSSMS_User();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SSMS__PASSWORD = eINSTANCE.getSSMS_Password();

		/**
		 * The meta object literal for the '<em><b>No Splash</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SSMS__NO_SPLASH = eINSTANCE.getSSMS_NoSplash();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ClipboardImpl <em>Clipboard</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ClipboardImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getClipboard()
		 * @generated
		 */
		EClass CLIPBOARD = eINSTANCE.getClipboard();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSeparatorImpl <em>String Separator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSeparatorImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringSeparator()
		 * @generated
		 */
		EClass STRING_SEPARATOR = eINSTANCE.getStringSeparator();

		/**
		 * The meta object literal for the '<em><b>Line Separator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_SEPARATOR__LINE_SEPARATOR = eINSTANCE.getStringSeparator_LineSeparator();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSplitterImpl <em>String Splitter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringSplitterImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringSplitter()
		 * @generated
		 */
		EClass STRING_SPLITTER = eINSTANCE.getStringSplitter();

		/**
		 * The meta object literal for the '<em><b>Split By</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_SPLITTER__SPLIT_BY = eINSTANCE.getStringSplitter_SplitBy();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringReplacerImpl <em>String Replacer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringReplacerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringReplacer()
		 * @generated
		 */
		EClass STRING_REPLACER = eINSTANCE.getStringReplacer();

		/**
		 * The meta object literal for the '<em><b>Regex</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_REPLACER__REGEX = eINSTANCE.getStringReplacer_Regex();

		/**
		 * The meta object literal for the '<em><b>Replacer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_REPLACER__REPLACER = eINSTANCE.getStringReplacer_Replacer();

		/**
		 * The meta object literal for the '<em><b>Replace All</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_REPLACER__REPLACE_ALL = eINSTANCE.getStringReplacer_ReplaceAll();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToXlsImpl <em>String To Xls</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToXlsImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToXls()
		 * @generated
		 */
		EClass STRING_TO_XLS = eINSTANCE.getStringToXls();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToFileImpl <em>String To File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToFileImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToFile()
		 * @generated
		 */
		EClass STRING_TO_FILE = eINSTANCE.getStringToFile();

		/**
		 * The meta object literal for the '<em><b>Extendsion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_TO_FILE__EXTENDSION = eINSTANCE.getStringToFile_Extendsion();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QuestionDialogImpl <em>Question Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.QuestionDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getQuestionDialog()
		 * @generated
		 */
		EClass QUESTION_DIALOG = eINSTANCE.getQuestionDialog();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InfoDialogImpl <em>Info Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InfoDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInfoDialog()
		 * @generated
		 */
		EClass INFO_DIALOG = eINSTANCE.getInfoDialog();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MessageDialogImpl <em>Message Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.MessageDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getMessageDialog()
		 * @generated
		 */
		EClass MESSAGE_DIALOG = eINSTANCE.getMessageDialog();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SelectionDialogImpl <em>Selection Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SelectionDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSelectionDialog()
		 * @generated
		 */
		EClass SELECTION_DIALOG = eINSTANCE.getSelectionDialog();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.FilteredDialogImpl <em>Filtered Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.FilteredDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getFilteredDialog()
		 * @generated
		 */
		EClass FILTERED_DIALOG = eINSTANCE.getFilteredDialog();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.EmailImpl <em>Email</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.EmailImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getEmail()
		 * @generated
		 */
		EClass EMAIL = eINSTANCE.getEmail();

		/**
		 * The meta object literal for the '<em><b>Receiper</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMAIL__RECEIPER = eINSTANCE.getEmail_Receiper();

		/**
		 * The meta object literal for the '<em><b>Topic</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMAIL__TOPIC = eINSTANCE.getEmail_Topic();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl <em>Csv Table Parser</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getCsvTableParser()
		 * @generated
		 */
		EClass CSV_TABLE_PARSER = eINSTANCE.getCsvTableParser();

		/**
		 * The meta object literal for the '<em><b>File Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CSV_TABLE_PARSER__FILE_PATH = eINSTANCE.getCsvTableParser_FilePath();

		/**
		 * The meta object literal for the '<em><b>Start Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CSV_TABLE_PARSER__START_INDEX = eINSTANCE.getCsvTableParser_StartIndex();

		/**
		 * The meta object literal for the '<em><b>End Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CSV_TABLE_PARSER__END_INDEX = eINSTANCE.getCsvTableParser_EndIndex();

		/**
		 * The meta object literal for the '<em><b>Split By</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CSV_TABLE_PARSER__SPLIT_BY = eINSTANCE.getCsvTableParser_SplitBy();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ChartImpl <em>Chart</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ChartImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getChart()
		 * @generated
		 */
		EClass CHART = eINSTANCE.getChart();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHART__TITLE = eINSTANCE.getChart_Title();

		/**
		 * The meta object literal for the '<em><b>XTitle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHART__XTITLE = eINSTANCE.getChart_XTitle();

		/**
		 * The meta object literal for the '<em><b>YTitle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHART__YTITLE = eINSTANCE.getChart_YTitle();

		/**
		 * The meta object literal for the '<em><b>Points</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHART__POINTS = eINSTANCE.getChart_Points();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PointImpl <em>Point</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PointImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPoint()
		 * @generated
		 */
		EClass POINT = eINSTANCE.getPoint();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POINT__X = eINSTANCE.getPoint_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POINT__Y = eINSTANCE.getPoint_Y();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.LineChartImpl <em>Line Chart</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.LineChartImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getLineChart()
		 * @generated
		 */
		EClass LINE_CHART = eINSTANCE.getLineChart();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.BarChartImpl <em>Bar Chart</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.BarChartImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getBarChart()
		 * @generated
		 */
		EClass BAR_CHART = eINSTANCE.getBarChart();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ScatterChartImpl <em>Scatter Chart</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ScatterChartImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getScatterChart()
		 * @generated
		 */
		EClass SCATTER_CHART = eINSTANCE.getScatterChart();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PieChartImpl <em>Pie Chart</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.PieChartImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getPieChart()
		 * @generated
		 */
		EClass PIE_CHART = eINSTANCE.getPieChart();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToListImpl <em>String To List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.StringToListImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getStringToList()
		 * @generated
		 */
		EClass STRING_TO_LIST = eINSTANCE.getStringToList();

		/**
		 * The meta object literal for the '<em><b>Sorter</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STRING_TO_LIST__SORTER = eINSTANCE.getStringToList_Sorter();

		/**
		 * The meta object literal for the '<em><b>List</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STRING_TO_LIST__LIST = eINSTANCE.getStringToList_List();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SorterImpl <em>Sorter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.SorterImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getSorter()
		 * @generated
		 */
		EClass SORTER = eINSTANCE.getSorter();

		/**
		 * The meta object literal for the '<em><b>Is Asc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SORTER__IS_ASC = eINSTANCE.getSorter_IsAsc();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListImpl <em>List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getList()
		 * @generated
		 */
		EClass LIST = eINSTANCE.getList();

		/**
		 * The meta object literal for the '<em><b>Items</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIST__ITEMS = eINSTANCE.getList_Items();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ItemImpl <em>Item</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ItemImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getItem()
		 * @generated
		 */
		EClass ITEM = eINSTANCE.getItem();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__NAME = eINSTANCE.getItem_Name();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__VALUE = eINSTANCE.getItem_Value();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacementImpl <em>Replacement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacementImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getReplacement()
		 * @generated
		 */
		EClass REPLACEMENT = eINSTANCE.getReplacement();

		/**
		 * The meta object literal for the '<em><b>Variable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REPLACEMENT__VARIABLE = eINSTANCE.getReplacement_Variable();

		/**
		 * The meta object literal for the '<em><b>Replacer</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REPLACEMENT__REPLACER = eINSTANCE.getReplacement_Replacer();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacerImpl <em>Replacer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ReplacerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getReplacer()
		 * @generated
		 */
		EClass REPLACER = eINSTANCE.getReplacer();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REPLACER__VALUE = eINSTANCE.getReplacer_Value();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionReplacerImpl <em>Option Replacer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionReplacerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOptionReplacer()
		 * @generated
		 */
		EClass OPTION_REPLACER = eINSTANCE.getOptionReplacer();

		/**
		 * The meta object literal for the '<em><b>Options</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPTION_REPLACER__OPTIONS = eINSTANCE.getOptionReplacer_Options();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionImpl <em>Option</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.OptionImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getOption()
		 * @generated
		 */
		EClass OPTION = eINSTANCE.getOption();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPTION__NAME = eINSTANCE.getOption_Name();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPTION__VALUE = eINSTANCE.getOption_Value();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputReplacerImpl <em>Input Replacer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputReplacerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInputReplacer()
		 * @generated
		 */
		EClass INPUT_REPLACER = eINSTANCE.getInputReplacer();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_REPLACER__TITLE = eINSTANCE.getInputReplacer_Title();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_REPLACER__MESSAGE = eINSTANCE.getInputReplacer_Message();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TimestampReplacerImpl <em>Timestamp Replacer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TimestampReplacerImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getTimestampReplacer()
		 * @generated
		 */
		EClass TIMESTAMP_REPLACER = eINSTANCE.getTimestampReplacer();

		/**
		 * The meta object literal for the '<em><b>Formatter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIMESTAMP_REPLACER__FORMATTER = eINSTANCE.getTimestampReplacer_Formatter();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputDialogImpl <em>Input Dialog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.InputDialogImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getInputDialog()
		 * @generated
		 */
		EClass INPUT_DIALOG = eINSTANCE.getInputDialog();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__TITLE = eINSTANCE.getInputDialog_Title();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__DESCRIPTION = eINSTANCE.getInputDialog_Description();

		/**
		 * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__HEIGHT = eINSTANCE.getInputDialog_Height();

		/**
		 * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__WIDTH = eINSTANCE.getInputDialog_Width();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__CONTENT = eINSTANCE.getInputDialog_Content();

		/**
		 * The meta object literal for the '<em><b>Use Template</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__USE_TEMPLATE = eINSTANCE.getInputDialog_UseTemplate();

		/**
		 * The meta object literal for the '<em><b>Template Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_DIALOG__TEMPLATE_NAME = eINSTANCE.getInputDialog_TemplateName();

		/**
		 * The meta object literal for the '<em><b>Controls</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_DIALOG__CONTROLS = eINSTANCE.getInputDialog_Controls();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_DIALOG__OPERATIONS = eINSTANCE.getInputDialog_Operations();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TextControlImpl <em>Text Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.TextControlImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getTextControl()
		 * @generated
		 */
		EClass TEXT_CONTROL = eINSTANCE.getTextControl();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DateControlImpl <em>Date Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.DateControlImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getDateControl()
		 * @generated
		 */
		EClass DATE_CONTROL = eINSTANCE.getDateControl();

		/**
		 * The meta object literal for the '<em><b>Formatter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATE_CONTROL__FORMATTER = eINSTANCE.getDateControl_Formatter();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListControlImpl <em>List Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ListControlImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getListControl()
		 * @generated
		 */
		EClass LIST_CONTROL = eINSTANCE.getListControl();

		/**
		 * The meta object literal for the '<em><b>Items</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIST_CONTROL__ITEMS = eINSTANCE.getListControl_Items();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboControlImpl <em>Combo Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboControlImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getComboControl()
		 * @generated
		 */
		EClass COMBO_CONTROL = eINSTANCE.getComboControl();

		/**
		 * The meta object literal for the '<em><b>Items</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMBO_CONTROL__ITEMS = eINSTANCE.getComboControl_Items();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboItemImpl <em>Combo Item</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ComboItemImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getComboItem()
		 * @generated
		 */
		EClass COMBO_ITEM = eINSTANCE.getComboItem();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMBO_ITEM__VALUE = eINSTANCE.getComboItem_Value();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ControlImpl <em>Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.ControlImpl
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getControl()
		 * @generated
		 */
		EClass CONTROL = eINSTANCE.getControl();

		/**
		 * The meta object literal for the '<em><b>Variable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL__VARIABLE = eINSTANCE.getControl_Variable();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL__VALUE = eINSTANCE.getControl_Value();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle <em>Form Style</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FormStyle
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getFormStyle()
		 * @generated
		 */
		EEnum FORM_STYLE = eINSTANCE.getFormStyle();

		/**
		 * The meta object literal for the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType <em>Exe Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ExeType
		 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowPackageImpl#getExeType()
		 * @generated
		 */
		EEnum EXE_TYPE = eINSTANCE.getExeType();

	}

} //WorkflowPackage
