/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getMove()
 * @model
 * @generated
 */
public interface Move extends Copy {
} // Move
