/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage
 * @generated
 */
public interface WorkflowFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WorkflowFactory eINSTANCE = de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.WorkflowFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Manager</em>'.
	 * @generated
	 */
	WorkflowManager createWorkflowManager();

	/**
	 * Returns a new object of class '<em>Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Workflow</em>'.
	 * @generated
	 */
	Workflow createWorkflow();

	/**
	 * Returns a new object of class '<em>DB Table View</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Table View</em>'.
	 * @generated
	 */
	DBTableView createDBTableView();

	/**
	 * Returns a new object of class '<em>DB Console</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Console</em>'.
	 * @generated
	 */
	DBConsole createDBConsole();

	/**
	 * Returns a new object of class '<em>DB Config</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Config</em>'.
	 * @generated
	 */
	DBConfig createDBConfig();

	/**
	 * Returns a new object of class '<em>Query</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Query</em>'.
	 * @generated
	 */
	Query createQuery();

	/**
	 * Returns a new object of class '<em>Prepared Query</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Prepared Query</em>'.
	 * @generated
	 */
	PreparedQuery createPreparedQuery();

	/**
	 * Returns a new object of class '<em>Path</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Path</em>'.
	 * @generated
	 */
	Path createPath();

	/**
	 * Returns a new object of class '<em>Named Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Named Element</em>'.
	 * @generated
	 */
	NamedElement createNamedElement();

	/**
	 * Returns a new object of class '<em>Mkdir</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mkdir</em>'.
	 * @generated
	 */
	Mkdir createMkdir();

	/**
	 * Returns a new object of class '<em>Copy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Copy</em>'.
	 * @generated
	 */
	Copy createCopy();

	/**
	 * Returns a new object of class '<em>Zip</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Zip</em>'.
	 * @generated
	 */
	Zip createZip();

	/**
	 * Returns a new object of class '<em>Move</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Move</em>'.
	 * @generated
	 */
	Move createMove();

	/**
	 * Returns a new object of class '<em>Rename</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rename</em>'.
	 * @generated
	 */
	Rename createRename();

	/**
	 * Returns a new object of class '<em>Delete</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delete</em>'.
	 * @generated
	 */
	Delete createDelete();

	/**
	 * Returns a new object of class '<em>Svn Commit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Svn Commit</em>'.
	 * @generated
	 */
	SvnCommit createSvnCommit();

	/**
	 * Returns a new object of class '<em>Svn Update</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Svn Update</em>'.
	 * @generated
	 */
	SvnUpdate createSvnUpdate();

	/**
	 * Returns a new object of class '<em>Git Commit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Git Commit</em>'.
	 * @generated
	 */
	GitCommit createGitCommit();

	/**
	 * Returns a new object of class '<em>Git Update</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Git Update</em>'.
	 * @generated
	 */
	GitUpdate createGitUpdate();

	/**
	 * Returns a new object of class '<em>Service Check</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service Check</em>'.
	 * @generated
	 */
	ServiceCheck createServiceCheck();

	/**
	 * Returns a new object of class '<em>Remote Desktop</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Remote Desktop</em>'.
	 * @generated
	 */
	RemoteDesktop createRemoteDesktop();

	/**
	 * Returns a new object of class '<em>Java</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java</em>'.
	 * @generated
	 */
	Java createJava();

	/**
	 * Returns a new object of class '<em>Exe</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Exe</em>'.
	 * @generated
	 */
	Exe createExe();

	/**
	 * Returns a new object of class '<em>SSMS</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>SSMS</em>'.
	 * @generated
	 */
	SSMS createSSMS();

	/**
	 * Returns a new object of class '<em>Clipboard</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Clipboard</em>'.
	 * @generated
	 */
	Clipboard createClipboard();

	/**
	 * Returns a new object of class '<em>String Separator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String Separator</em>'.
	 * @generated
	 */
	StringSeparator createStringSeparator();

	/**
	 * Returns a new object of class '<em>String Splitter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String Splitter</em>'.
	 * @generated
	 */
	StringSplitter createStringSplitter();

	/**
	 * Returns a new object of class '<em>String Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String Replacer</em>'.
	 * @generated
	 */
	StringReplacer createStringReplacer();

	/**
	 * Returns a new object of class '<em>String To Xls</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String To Xls</em>'.
	 * @generated
	 */
	StringToXls createStringToXls();

	/**
	 * Returns a new object of class '<em>String To File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String To File</em>'.
	 * @generated
	 */
	StringToFile createStringToFile();

	/**
	 * Returns a new object of class '<em>Question Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Question Dialog</em>'.
	 * @generated
	 */
	QuestionDialog createQuestionDialog();

	/**
	 * Returns a new object of class '<em>Info Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Info Dialog</em>'.
	 * @generated
	 */
	InfoDialog createInfoDialog();

	/**
	 * Returns a new object of class '<em>Message Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Message Dialog</em>'.
	 * @generated
	 */
	MessageDialog createMessageDialog();

	/**
	 * Returns a new object of class '<em>Selection Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Selection Dialog</em>'.
	 * @generated
	 */
	SelectionDialog createSelectionDialog();

	/**
	 * Returns a new object of class '<em>Filtered Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Filtered Dialog</em>'.
	 * @generated
	 */
	FilteredDialog createFilteredDialog();

	/**
	 * Returns a new object of class '<em>Email</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Email</em>'.
	 * @generated
	 */
	Email createEmail();

	/**
	 * Returns a new object of class '<em>Csv Table Parser</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Csv Table Parser</em>'.
	 * @generated
	 */
	CsvTableParser createCsvTableParser();

	/**
	 * Returns a new object of class '<em>Point</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Point</em>'.
	 * @generated
	 */
	Point createPoint();

	/**
	 * Returns a new object of class '<em>Line Chart</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Line Chart</em>'.
	 * @generated
	 */
	LineChart createLineChart();

	/**
	 * Returns a new object of class '<em>Bar Chart</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Bar Chart</em>'.
	 * @generated
	 */
	BarChart createBarChart();

	/**
	 * Returns a new object of class '<em>Scatter Chart</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scatter Chart</em>'.
	 * @generated
	 */
	ScatterChart createScatterChart();

	/**
	 * Returns a new object of class '<em>Pie Chart</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pie Chart</em>'.
	 * @generated
	 */
	PieChart createPieChart();

	/**
	 * Returns a new object of class '<em>String To List</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String To List</em>'.
	 * @generated
	 */
	StringToList createStringToList();

	/**
	 * Returns a new object of class '<em>Sorter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sorter</em>'.
	 * @generated
	 */
	Sorter createSorter();

	/**
	 * Returns a new object of class '<em>List</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>List</em>'.
	 * @generated
	 */
	List createList();

	/**
	 * Returns a new object of class '<em>Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Item</em>'.
	 * @generated
	 */
	Item createItem();

	/**
	 * Returns a new object of class '<em>Replacement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Replacement</em>'.
	 * @generated
	 */
	Replacement createReplacement();

	/**
	 * Returns a new object of class '<em>Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Replacer</em>'.
	 * @generated
	 */
	Replacer createReplacer();

	/**
	 * Returns a new object of class '<em>Option Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Option Replacer</em>'.
	 * @generated
	 */
	OptionReplacer createOptionReplacer();

	/**
	 * Returns a new object of class '<em>Option</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Option</em>'.
	 * @generated
	 */
	Option createOption();

	/**
	 * Returns a new object of class '<em>Input Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Replacer</em>'.
	 * @generated
	 */
	InputReplacer createInputReplacer();

	/**
	 * Returns a new object of class '<em>Timestamp Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Timestamp Replacer</em>'.
	 * @generated
	 */
	TimestampReplacer createTimestampReplacer();

	/**
	 * Returns a new object of class '<em>Input Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Dialog</em>'.
	 * @generated
	 */
	InputDialog createInputDialog();

	/**
	 * Returns a new object of class '<em>Text Control</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Control</em>'.
	 * @generated
	 */
	TextControl createTextControl();

	/**
	 * Returns a new object of class '<em>Date Control</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Date Control</em>'.
	 * @generated
	 */
	DateControl createDateControl();

	/**
	 * Returns a new object of class '<em>List Control</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>List Control</em>'.
	 * @generated
	 */
	ListControl createListControl();

	/**
	 * Returns a new object of class '<em>Combo Control</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Combo Control</em>'.
	 * @generated
	 */
	ComboControl createComboControl();

	/**
	 * Returns a new object of class '<em>Combo Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Combo Item</em>'.
	 * @generated
	 */
	ComboItem createComboItem();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	WorkflowPackage getWorkflowPackage();

} //WorkflowFactory
