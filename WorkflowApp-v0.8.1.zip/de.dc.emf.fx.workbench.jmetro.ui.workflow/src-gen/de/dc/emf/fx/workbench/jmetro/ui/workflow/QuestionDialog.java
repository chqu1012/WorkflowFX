/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Question Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getQuestionDialog()
 * @model
 * @generated
 */
public interface QuestionDialog extends EObject {
} // QuestionDialog
