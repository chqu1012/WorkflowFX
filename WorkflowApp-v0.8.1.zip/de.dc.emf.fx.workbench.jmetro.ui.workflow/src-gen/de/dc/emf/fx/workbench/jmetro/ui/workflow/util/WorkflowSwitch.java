/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage
 * @generated
 */
public class WorkflowSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WorkflowPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowSwitch() {
		if (modelPackage == null) {
			modelPackage = WorkflowPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case WorkflowPackage.WORKFLOW_MANAGER: {
			WorkflowManager workflowManager = (WorkflowManager) theEObject;
			T result = caseWorkflowManager(workflowManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.WORKFLOW: {
			Workflow workflow = (Workflow) theEObject;
			T result = caseWorkflow(workflow);
			if (result == null)
				result = caseNamedElement(workflow);
			if (result == null)
				result = caseContent(workflow);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.VIEW: {
			View view = (View) theEObject;
			T result = caseView(view);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.DB_TABLE_VIEW: {
			DBTableView dbTableView = (DBTableView) theEObject;
			T result = caseDBTableView(dbTableView);
			if (result == null)
				result = caseView(dbTableView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.DB_CONSOLE: {
			DBConsole dbConsole = (DBConsole) theEObject;
			T result = caseDBConsole(dbConsole);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.DB_CONFIG: {
			DBConfig dbConfig = (DBConfig) theEObject;
			T result = caseDBConfig(dbConfig);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.QUERY: {
			Query query = (Query) theEObject;
			T result = caseQuery(query);
			if (result == null)
				result = caseContent(query);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.PREPARED_QUERY: {
			PreparedQuery preparedQuery = (PreparedQuery) theEObject;
			T result = casePreparedQuery(preparedQuery);
			if (result == null)
				result = caseQuery(preparedQuery);
			if (result == null)
				result = caseContent(preparedQuery);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.OPERATION: {
			Operation operation = (Operation) theEObject;
			T result = caseOperation(operation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.CONTENT: {
			Content content = (Content) theEObject;
			T result = caseContent(content);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.PATH: {
			Path path = (Path) theEObject;
			T result = casePath(path);
			if (result == null)
				result = caseContent(path);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.NAMED_ELEMENT: {
			NamedElement namedElement = (NamedElement) theEObject;
			T result = caseNamedElement(namedElement);
			if (result == null)
				result = caseContent(namedElement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.MKDIR: {
			Mkdir mkdir = (Mkdir) theEObject;
			T result = caseMkdir(mkdir);
			if (result == null)
				result = caseOperation(mkdir);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.COPY: {
			Copy copy = (Copy) theEObject;
			T result = caseCopy(copy);
			if (result == null)
				result = caseOperation(copy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.ZIP: {
			Zip zip = (Zip) theEObject;
			T result = caseZip(zip);
			if (result == null)
				result = caseCopy(zip);
			if (result == null)
				result = caseOperation(zip);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.MOVE: {
			Move move = (Move) theEObject;
			T result = caseMove(move);
			if (result == null)
				result = caseCopy(move);
			if (result == null)
				result = caseOperation(move);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.RENAME: {
			Rename rename = (Rename) theEObject;
			T result = caseRename(rename);
			if (result == null)
				result = caseCopy(rename);
			if (result == null)
				result = caseOperation(rename);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.DELETE: {
			Delete delete = (Delete) theEObject;
			T result = caseDelete(delete);
			if (result == null)
				result = caseCopy(delete);
			if (result == null)
				result = caseOperation(delete);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SVN_COMMIT: {
			SvnCommit svnCommit = (SvnCommit) theEObject;
			T result = caseSvnCommit(svnCommit);
			if (result == null)
				result = caseOperation(svnCommit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SVN_UPDATE: {
			SvnUpdate svnUpdate = (SvnUpdate) theEObject;
			T result = caseSvnUpdate(svnUpdate);
			if (result == null)
				result = caseOperation(svnUpdate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.GIT_COMMIT: {
			GitCommit gitCommit = (GitCommit) theEObject;
			T result = caseGitCommit(gitCommit);
			if (result == null)
				result = caseOperation(gitCommit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.GIT_UPDATE: {
			GitUpdate gitUpdate = (GitUpdate) theEObject;
			T result = caseGitUpdate(gitUpdate);
			if (result == null)
				result = caseOperation(gitUpdate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SERVICE_CHECK: {
			ServiceCheck serviceCheck = (ServiceCheck) theEObject;
			T result = caseServiceCheck(serviceCheck);
			if (result == null)
				result = caseOperation(serviceCheck);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.REMOTE_DESKTOP: {
			RemoteDesktop remoteDesktop = (RemoteDesktop) theEObject;
			T result = caseRemoteDesktop(remoteDesktop);
			if (result == null)
				result = caseOperation(remoteDesktop);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.JAVA: {
			Java java = (Java) theEObject;
			T result = caseJava(java);
			if (result == null)
				result = caseCopy(java);
			if (result == null)
				result = caseOperation(java);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.EXE: {
			Exe exe = (Exe) theEObject;
			T result = caseExe(exe);
			if (result == null)
				result = caseOperation(exe);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SSMS: {
			SSMS ssms = (SSMS) theEObject;
			T result = caseSSMS(ssms);
			if (result == null)
				result = caseOperation(ssms);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.CLIPBOARD: {
			Clipboard clipboard = (Clipboard) theEObject;
			T result = caseClipboard(clipboard);
			if (result == null)
				result = caseOperation(clipboard);
			if (result == null)
				result = caseContent(clipboard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_SEPARATOR: {
			StringSeparator stringSeparator = (StringSeparator) theEObject;
			T result = caseStringSeparator(stringSeparator);
			if (result == null)
				result = caseClipboard(stringSeparator);
			if (result == null)
				result = caseOperation(stringSeparator);
			if (result == null)
				result = caseContent(stringSeparator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_SPLITTER: {
			StringSplitter stringSplitter = (StringSplitter) theEObject;
			T result = caseStringSplitter(stringSplitter);
			if (result == null)
				result = caseClipboard(stringSplitter);
			if (result == null)
				result = caseOperation(stringSplitter);
			if (result == null)
				result = caseContent(stringSplitter);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_REPLACER: {
			StringReplacer stringReplacer = (StringReplacer) theEObject;
			T result = caseStringReplacer(stringReplacer);
			if (result == null)
				result = caseClipboard(stringReplacer);
			if (result == null)
				result = caseOperation(stringReplacer);
			if (result == null)
				result = caseContent(stringReplacer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_TO_XLS: {
			StringToXls stringToXls = (StringToXls) theEObject;
			T result = caseStringToXls(stringToXls);
			if (result == null)
				result = caseClipboard(stringToXls);
			if (result == null)
				result = caseOperation(stringToXls);
			if (result == null)
				result = caseContent(stringToXls);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_TO_FILE: {
			StringToFile stringToFile = (StringToFile) theEObject;
			T result = caseStringToFile(stringToFile);
			if (result == null)
				result = caseClipboard(stringToFile);
			if (result == null)
				result = caseOperation(stringToFile);
			if (result == null)
				result = caseContent(stringToFile);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.QUESTION_DIALOG: {
			QuestionDialog questionDialog = (QuestionDialog) theEObject;
			T result = caseQuestionDialog(questionDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.INFO_DIALOG: {
			InfoDialog infoDialog = (InfoDialog) theEObject;
			T result = caseInfoDialog(infoDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.MESSAGE_DIALOG: {
			MessageDialog messageDialog = (MessageDialog) theEObject;
			T result = caseMessageDialog(messageDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SELECTION_DIALOG: {
			SelectionDialog selectionDialog = (SelectionDialog) theEObject;
			T result = caseSelectionDialog(selectionDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.FILTERED_DIALOG: {
			FilteredDialog filteredDialog = (FilteredDialog) theEObject;
			T result = caseFilteredDialog(filteredDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.EMAIL: {
			Email email = (Email) theEObject;
			T result = caseEmail(email);
			if (result == null)
				result = caseContent(email);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.CSV_TABLE_PARSER: {
			CsvTableParser csvTableParser = (CsvTableParser) theEObject;
			T result = caseCsvTableParser(csvTableParser);
			if (result == null)
				result = caseView(csvTableParser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.CHART: {
			Chart chart = (Chart) theEObject;
			T result = caseChart(chart);
			if (result == null)
				result = caseView(chart);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.POINT: {
			Point point = (Point) theEObject;
			T result = casePoint(point);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.LINE_CHART: {
			LineChart lineChart = (LineChart) theEObject;
			T result = caseLineChart(lineChart);
			if (result == null)
				result = caseChart(lineChart);
			if (result == null)
				result = caseView(lineChart);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.BAR_CHART: {
			BarChart barChart = (BarChart) theEObject;
			T result = caseBarChart(barChart);
			if (result == null)
				result = caseChart(barChart);
			if (result == null)
				result = caseView(barChart);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SCATTER_CHART: {
			ScatterChart scatterChart = (ScatterChart) theEObject;
			T result = caseScatterChart(scatterChart);
			if (result == null)
				result = caseChart(scatterChart);
			if (result == null)
				result = caseView(scatterChart);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.PIE_CHART: {
			PieChart pieChart = (PieChart) theEObject;
			T result = casePieChart(pieChart);
			if (result == null)
				result = caseChart(pieChart);
			if (result == null)
				result = caseView(pieChart);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.STRING_TO_LIST: {
			StringToList stringToList = (StringToList) theEObject;
			T result = caseStringToList(stringToList);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.SORTER: {
			Sorter sorter = (Sorter) theEObject;
			T result = caseSorter(sorter);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.LIST: {
			List list = (List) theEObject;
			T result = caseList(list);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.ITEM: {
			Item item = (Item) theEObject;
			T result = caseItem(item);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.REPLACEMENT: {
			Replacement replacement = (Replacement) theEObject;
			T result = caseReplacement(replacement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.REPLACER: {
			Replacer replacer = (Replacer) theEObject;
			T result = caseReplacer(replacer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.OPTION_REPLACER: {
			OptionReplacer optionReplacer = (OptionReplacer) theEObject;
			T result = caseOptionReplacer(optionReplacer);
			if (result == null)
				result = caseReplacer(optionReplacer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.OPTION: {
			Option option = (Option) theEObject;
			T result = caseOption(option);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.INPUT_REPLACER: {
			InputReplacer inputReplacer = (InputReplacer) theEObject;
			T result = caseInputReplacer(inputReplacer);
			if (result == null)
				result = caseReplacer(inputReplacer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.TIMESTAMP_REPLACER: {
			TimestampReplacer timestampReplacer = (TimestampReplacer) theEObject;
			T result = caseTimestampReplacer(timestampReplacer);
			if (result == null)
				result = caseReplacer(timestampReplacer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.INPUT_DIALOG: {
			InputDialog inputDialog = (InputDialog) theEObject;
			T result = caseInputDialog(inputDialog);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.TEXT_CONTROL: {
			TextControl textControl = (TextControl) theEObject;
			T result = caseTextControl(textControl);
			if (result == null)
				result = caseControl(textControl);
			if (result == null)
				result = caseNamedElement(textControl);
			if (result == null)
				result = caseContent(textControl);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.DATE_CONTROL: {
			DateControl dateControl = (DateControl) theEObject;
			T result = caseDateControl(dateControl);
			if (result == null)
				result = caseTextControl(dateControl);
			if (result == null)
				result = caseControl(dateControl);
			if (result == null)
				result = caseNamedElement(dateControl);
			if (result == null)
				result = caseContent(dateControl);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.LIST_CONTROL: {
			ListControl listControl = (ListControl) theEObject;
			T result = caseListControl(listControl);
			if (result == null)
				result = caseControl(listControl);
			if (result == null)
				result = caseNamedElement(listControl);
			if (result == null)
				result = caseContent(listControl);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.COMBO_CONTROL: {
			ComboControl comboControl = (ComboControl) theEObject;
			T result = caseComboControl(comboControl);
			if (result == null)
				result = caseControl(comboControl);
			if (result == null)
				result = caseNamedElement(comboControl);
			if (result == null)
				result = caseContent(comboControl);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.COMBO_ITEM: {
			ComboItem comboItem = (ComboItem) theEObject;
			T result = caseComboItem(comboItem);
			if (result == null)
				result = caseContent(comboItem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case WorkflowPackage.CONTROL: {
			Control control = (Control) theEObject;
			T result = caseControl(control);
			if (result == null)
				result = caseNamedElement(control);
			if (result == null)
				result = caseContent(control);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWorkflowManager(WorkflowManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Workflow</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWorkflow(Workflow object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseView(View object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DB Table View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DB Table View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDBTableView(DBTableView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DB Console</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DB Console</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDBConsole(DBConsole object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DB Config</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DB Config</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDBConfig(DBConfig object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Query</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Query</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseQuery(Query object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Prepared Query</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Prepared Query</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreparedQuery(PreparedQuery object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Operation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Operation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOperation(Operation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Content</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Content</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContent(Content object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Path</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Path</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePath(Path object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Named Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Named Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNamedElement(NamedElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mkdir</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mkdir</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMkdir(Mkdir object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Copy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Copy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCopy(Copy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Zip</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Zip</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseZip(Zip object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Move</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Move</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMove(Move object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Rename</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Rename</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRename(Rename object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Delete</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Delete</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDelete(Delete object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Svn Commit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Svn Commit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSvnCommit(SvnCommit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Svn Update</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Svn Update</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSvnUpdate(SvnUpdate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Git Commit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Git Commit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGitCommit(GitCommit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Git Update</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Git Update</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGitUpdate(GitUpdate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service Check</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service Check</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServiceCheck(ServiceCheck object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remote Desktop</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remote Desktop</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoteDesktop(RemoteDesktop object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJava(Java object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Exe</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Exe</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExe(Exe object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>SSMS</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>SSMS</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSSMS(SSMS object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Clipboard</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Clipboard</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClipboard(Clipboard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String Separator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String Separator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringSeparator(StringSeparator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String Splitter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String Splitter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringSplitter(StringSplitter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String Replacer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringReplacer(StringReplacer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String To Xls</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String To Xls</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringToXls(StringToXls object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String To File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String To File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringToFile(StringToFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Question Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Question Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseQuestionDialog(QuestionDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Info Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Info Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInfoDialog(InfoDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Message Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Message Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMessageDialog(MessageDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Selection Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Selection Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSelectionDialog(SelectionDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Filtered Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Filtered Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFilteredDialog(FilteredDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Email</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Email</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEmail(Email object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Csv Table Parser</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Csv Table Parser</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCsvTableParser(CsvTableParser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Chart</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Chart</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseChart(Chart object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Point</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Point</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePoint(Point object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Line Chart</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Line Chart</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLineChart(LineChart object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bar Chart</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bar Chart</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBarChart(BarChart object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Scatter Chart</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Scatter Chart</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseScatterChart(ScatterChart object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pie Chart</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pie Chart</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePieChart(PieChart object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String To List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String To List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringToList(StringToList object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sorter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sorter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSorter(Sorter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseList(List object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Item</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Item</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseItem(Item object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Replacement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Replacement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReplacement(Replacement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Replacer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReplacer(Replacer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Option Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Option Replacer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOptionReplacer(OptionReplacer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Option</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Option</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOption(Option object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Replacer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputReplacer(InputReplacer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Timestamp Replacer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Timestamp Replacer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTimestampReplacer(TimestampReplacer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Dialog</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Dialog</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputDialog(InputDialog object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Text Control</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Text Control</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTextControl(TextControl object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Date Control</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Date Control</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDateControl(DateControl object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>List Control</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>List Control</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseListControl(ListControl object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Combo Control</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Combo Control</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComboControl(ComboControl object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Combo Item</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Combo Item</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComboItem(ComboItem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Control</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Control</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseControl(Control object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //WorkflowSwitch
