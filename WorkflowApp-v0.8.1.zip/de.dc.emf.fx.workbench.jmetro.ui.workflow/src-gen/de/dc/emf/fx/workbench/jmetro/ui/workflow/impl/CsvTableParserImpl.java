/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.impl;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Csv Table Parser</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl#getFilePath <em>File Path</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl#getStartIndex <em>Start Index</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl#getEndIndex <em>End Index</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.impl.CsvTableParserImpl#getSplitBy <em>Split By</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CsvTableParserImpl extends ViewImpl implements CsvTableParser {
	/**
	 * The default value of the '{@link #getFilePath() <em>File Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilePath()
	 * @generated
	 * @ordered
	 */
	protected static final String FILE_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFilePath() <em>File Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilePath()
	 * @generated
	 * @ordered
	 */
	protected String filePath = FILE_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getStartIndex() <em>Start Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartIndex()
	 * @generated
	 * @ordered
	 */
	protected static final int START_INDEX_EDEFAULT = 1;

	/**
	 * The cached value of the '{@link #getStartIndex() <em>Start Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartIndex()
	 * @generated
	 * @ordered
	 */
	protected int startIndex = START_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndIndex() <em>End Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndIndex()
	 * @generated
	 * @ordered
	 */
	protected static final int END_INDEX_EDEFAULT = 100;

	/**
	 * The cached value of the '{@link #getEndIndex() <em>End Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndIndex()
	 * @generated
	 * @ordered
	 */
	protected int endIndex = END_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getSplitBy() <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSplitBy()
	 * @generated
	 * @ordered
	 */
	protected static final String SPLIT_BY_EDEFAULT = ";";

	/**
	 * The cached value of the '{@link #getSplitBy() <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSplitBy()
	 * @generated
	 * @ordered
	 */
	protected String splitBy = SPLIT_BY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CsvTableParserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.CSV_TABLE_PARSER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFilePath() {
		return filePath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFilePath(String newFilePath) {
		String oldFilePath = filePath;
		filePath = newFilePath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.CSV_TABLE_PARSER__FILE_PATH,
					oldFilePath, filePath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getStartIndex() {
		return startIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStartIndex(int newStartIndex) {
		int oldStartIndex = startIndex;
		startIndex = newStartIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.CSV_TABLE_PARSER__START_INDEX,
					oldStartIndex, startIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEndIndex(int newEndIndex) {
		int oldEndIndex = endIndex;
		endIndex = newEndIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.CSV_TABLE_PARSER__END_INDEX,
					oldEndIndex, endIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSplitBy() {
		return splitBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSplitBy(String newSplitBy) {
		String oldSplitBy = splitBy;
		splitBy = newSplitBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.CSV_TABLE_PARSER__SPLIT_BY,
					oldSplitBy, splitBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case WorkflowPackage.CSV_TABLE_PARSER__FILE_PATH:
			return getFilePath();
		case WorkflowPackage.CSV_TABLE_PARSER__START_INDEX:
			return getStartIndex();
		case WorkflowPackage.CSV_TABLE_PARSER__END_INDEX:
			return getEndIndex();
		case WorkflowPackage.CSV_TABLE_PARSER__SPLIT_BY:
			return getSplitBy();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case WorkflowPackage.CSV_TABLE_PARSER__FILE_PATH:
			setFilePath((String) newValue);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__START_INDEX:
			setStartIndex((Integer) newValue);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__END_INDEX:
			setEndIndex((Integer) newValue);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__SPLIT_BY:
			setSplitBy((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case WorkflowPackage.CSV_TABLE_PARSER__FILE_PATH:
			setFilePath(FILE_PATH_EDEFAULT);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__START_INDEX:
			setStartIndex(START_INDEX_EDEFAULT);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__END_INDEX:
			setEndIndex(END_INDEX_EDEFAULT);
			return;
		case WorkflowPackage.CSV_TABLE_PARSER__SPLIT_BY:
			setSplitBy(SPLIT_BY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case WorkflowPackage.CSV_TABLE_PARSER__FILE_PATH:
			return FILE_PATH_EDEFAULT == null ? filePath != null : !FILE_PATH_EDEFAULT.equals(filePath);
		case WorkflowPackage.CSV_TABLE_PARSER__START_INDEX:
			return startIndex != START_INDEX_EDEFAULT;
		case WorkflowPackage.CSV_TABLE_PARSER__END_INDEX:
			return endIndex != END_INDEX_EDEFAULT;
		case WorkflowPackage.CSV_TABLE_PARSER__SPLIT_BY:
			return SPLIT_BY_EDEFAULT == null ? splitBy != null : !SPLIT_BY_EDEFAULT.equals(splitBy);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (filePath: ");
		result.append(filePath);
		result.append(", startIndex: ");
		result.append(startIndex);
		result.append(", endIndex: ");
		result.append(endIndex);
		result.append(", splitBy: ");
		result.append(splitBy);
		result.append(')');
		return result.toString();
	}

} //CsvTableParserImpl
