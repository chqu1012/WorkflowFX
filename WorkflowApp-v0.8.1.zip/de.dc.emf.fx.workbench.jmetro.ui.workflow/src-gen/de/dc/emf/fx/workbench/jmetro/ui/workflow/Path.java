/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Path</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getPath()
 * @model
 * @generated
 */
public interface Path extends Content {
} // Path
