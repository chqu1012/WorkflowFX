/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.impl;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.FilteredDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Filtered Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FilteredDialogImpl extends MinimalEObjectImpl.Container implements FilteredDialog {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FilteredDialogImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.FILTERED_DIALOG;
	}

} //FilteredDialogImpl
