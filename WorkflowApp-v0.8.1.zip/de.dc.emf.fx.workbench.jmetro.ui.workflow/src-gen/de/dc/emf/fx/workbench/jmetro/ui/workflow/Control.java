/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getVariable <em>Variable</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getControl()
 * @model abstract="true"
 * @generated
 */
public interface Control extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Variable</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variable</em>' attribute.
	 * @see #setVariable(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getControl_Variable()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getVariable();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getVariable <em>Variable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Variable</em>' attribute.
	 * @see #getVariable()
	 * @generated
	 */
	void setVariable(String value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getControl_Value()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

} // Control
