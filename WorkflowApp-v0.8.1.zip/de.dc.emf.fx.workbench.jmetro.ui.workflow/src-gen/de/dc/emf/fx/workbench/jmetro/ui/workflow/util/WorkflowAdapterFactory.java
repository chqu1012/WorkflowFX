/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.util;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage
 * @generated
 */
public class WorkflowAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WorkflowPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = WorkflowPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WorkflowSwitch<Adapter> modelSwitch = new WorkflowSwitch<Adapter>() {
		@Override
		public Adapter caseWorkflowManager(WorkflowManager object) {
			return createWorkflowManagerAdapter();
		}

		@Override
		public Adapter caseWorkflow(Workflow object) {
			return createWorkflowAdapter();
		}

		@Override
		public Adapter caseView(View object) {
			return createViewAdapter();
		}

		@Override
		public Adapter caseDBTableView(DBTableView object) {
			return createDBTableViewAdapter();
		}

		@Override
		public Adapter caseDBConsole(DBConsole object) {
			return createDBConsoleAdapter();
		}

		@Override
		public Adapter caseDBConfig(DBConfig object) {
			return createDBConfigAdapter();
		}

		@Override
		public Adapter caseQuery(Query object) {
			return createQueryAdapter();
		}

		@Override
		public Adapter casePreparedQuery(PreparedQuery object) {
			return createPreparedQueryAdapter();
		}

		@Override
		public Adapter caseOperation(Operation object) {
			return createOperationAdapter();
		}

		@Override
		public Adapter caseContent(Content object) {
			return createContentAdapter();
		}

		@Override
		public Adapter casePath(Path object) {
			return createPathAdapter();
		}

		@Override
		public Adapter caseNamedElement(NamedElement object) {
			return createNamedElementAdapter();
		}

		@Override
		public Adapter caseMkdir(Mkdir object) {
			return createMkdirAdapter();
		}

		@Override
		public Adapter caseCopy(Copy object) {
			return createCopyAdapter();
		}

		@Override
		public Adapter caseZip(Zip object) {
			return createZipAdapter();
		}

		@Override
		public Adapter caseMove(Move object) {
			return createMoveAdapter();
		}

		@Override
		public Adapter caseRename(Rename object) {
			return createRenameAdapter();
		}

		@Override
		public Adapter caseDelete(Delete object) {
			return createDeleteAdapter();
		}

		@Override
		public Adapter caseSvnCommit(SvnCommit object) {
			return createSvnCommitAdapter();
		}

		@Override
		public Adapter caseSvnUpdate(SvnUpdate object) {
			return createSvnUpdateAdapter();
		}

		@Override
		public Adapter caseGitCommit(GitCommit object) {
			return createGitCommitAdapter();
		}

		@Override
		public Adapter caseGitUpdate(GitUpdate object) {
			return createGitUpdateAdapter();
		}

		@Override
		public Adapter caseServiceCheck(ServiceCheck object) {
			return createServiceCheckAdapter();
		}

		@Override
		public Adapter caseRemoteDesktop(RemoteDesktop object) {
			return createRemoteDesktopAdapter();
		}

		@Override
		public Adapter caseJava(Java object) {
			return createJavaAdapter();
		}

		@Override
		public Adapter caseExe(Exe object) {
			return createExeAdapter();
		}

		@Override
		public Adapter caseSSMS(SSMS object) {
			return createSSMSAdapter();
		}

		@Override
		public Adapter caseClipboard(Clipboard object) {
			return createClipboardAdapter();
		}

		@Override
		public Adapter caseStringSeparator(StringSeparator object) {
			return createStringSeparatorAdapter();
		}

		@Override
		public Adapter caseStringSplitter(StringSplitter object) {
			return createStringSplitterAdapter();
		}

		@Override
		public Adapter caseStringReplacer(StringReplacer object) {
			return createStringReplacerAdapter();
		}

		@Override
		public Adapter caseStringToXls(StringToXls object) {
			return createStringToXlsAdapter();
		}

		@Override
		public Adapter caseStringToFile(StringToFile object) {
			return createStringToFileAdapter();
		}

		@Override
		public Adapter caseQuestionDialog(QuestionDialog object) {
			return createQuestionDialogAdapter();
		}

		@Override
		public Adapter caseInfoDialog(InfoDialog object) {
			return createInfoDialogAdapter();
		}

		@Override
		public Adapter caseMessageDialog(MessageDialog object) {
			return createMessageDialogAdapter();
		}

		@Override
		public Adapter caseSelectionDialog(SelectionDialog object) {
			return createSelectionDialogAdapter();
		}

		@Override
		public Adapter caseFilteredDialog(FilteredDialog object) {
			return createFilteredDialogAdapter();
		}

		@Override
		public Adapter caseEmail(Email object) {
			return createEmailAdapter();
		}

		@Override
		public Adapter caseCsvTableParser(CsvTableParser object) {
			return createCsvTableParserAdapter();
		}

		@Override
		public Adapter caseChart(Chart object) {
			return createChartAdapter();
		}

		@Override
		public Adapter casePoint(Point object) {
			return createPointAdapter();
		}

		@Override
		public Adapter caseLineChart(LineChart object) {
			return createLineChartAdapter();
		}

		@Override
		public Adapter caseBarChart(BarChart object) {
			return createBarChartAdapter();
		}

		@Override
		public Adapter caseScatterChart(ScatterChart object) {
			return createScatterChartAdapter();
		}

		@Override
		public Adapter casePieChart(PieChart object) {
			return createPieChartAdapter();
		}

		@Override
		public Adapter caseStringToList(StringToList object) {
			return createStringToListAdapter();
		}

		@Override
		public Adapter caseSorter(Sorter object) {
			return createSorterAdapter();
		}

		@Override
		public Adapter caseList(List object) {
			return createListAdapter();
		}

		@Override
		public Adapter caseItem(Item object) {
			return createItemAdapter();
		}

		@Override
		public Adapter caseReplacement(Replacement object) {
			return createReplacementAdapter();
		}

		@Override
		public Adapter caseReplacer(Replacer object) {
			return createReplacerAdapter();
		}

		@Override
		public Adapter caseOptionReplacer(OptionReplacer object) {
			return createOptionReplacerAdapter();
		}

		@Override
		public Adapter caseOption(Option object) {
			return createOptionAdapter();
		}

		@Override
		public Adapter caseInputReplacer(InputReplacer object) {
			return createInputReplacerAdapter();
		}

		@Override
		public Adapter caseTimestampReplacer(TimestampReplacer object) {
			return createTimestampReplacerAdapter();
		}

		@Override
		public Adapter caseInputDialog(InputDialog object) {
			return createInputDialogAdapter();
		}

		@Override
		public Adapter caseTextControl(TextControl object) {
			return createTextControlAdapter();
		}

		@Override
		public Adapter caseDateControl(DateControl object) {
			return createDateControlAdapter();
		}

		@Override
		public Adapter caseListControl(ListControl object) {
			return createListControlAdapter();
		}

		@Override
		public Adapter caseComboControl(ComboControl object) {
			return createComboControlAdapter();
		}

		@Override
		public Adapter caseComboItem(ComboItem object) {
			return createComboItemAdapter();
		}

		@Override
		public Adapter caseControl(Control object) {
			return createControlAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowManager
	 * @generated
	 */
	public Adapter createWorkflowManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Workflow
	 * @generated
	 */
	public Adapter createWorkflowAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.View <em>View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.View
	 * @generated
	 */
	public Adapter createViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView <em>DB Table View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView
	 * @generated
	 */
	public Adapter createDBTableViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole <em>DB Console</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConsole
	 * @generated
	 */
	public Adapter createDBConsoleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig <em>DB Config</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DBConfig
	 * @generated
	 */
	public Adapter createDBConfigAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Query <em>Query</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Query
	 * @generated
	 */
	public Adapter createQueryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.PreparedQuery <em>Prepared Query</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.PreparedQuery
	 * @generated
	 */
	public Adapter createPreparedQueryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation
	 * @generated
	 */
	public Adapter createOperationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Content <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Content
	 * @generated
	 */
	public Adapter createContentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Path <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Path
	 * @generated
	 */
	public Adapter createPathAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.NamedElement <em>Named Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.NamedElement
	 * @generated
	 */
	public Adapter createNamedElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir <em>Mkdir</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir
	 * @generated
	 */
	public Adapter createMkdirAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy <em>Copy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Copy
	 * @generated
	 */
	public Adapter createCopyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Zip <em>Zip</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Zip
	 * @generated
	 */
	public Adapter createZipAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Move <em>Move</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Move
	 * @generated
	 */
	public Adapter createMoveAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Rename <em>Rename</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Rename
	 * @generated
	 */
	public Adapter createRenameAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete <em>Delete</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Delete
	 * @generated
	 */
	public Adapter createDeleteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnCommit <em>Svn Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnCommit
	 * @generated
	 */
	public Adapter createSvnCommitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnUpdate <em>Svn Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SvnUpdate
	 * @generated
	 */
	public Adapter createSvnUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.GitCommit <em>Git Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.GitCommit
	 * @generated
	 */
	public Adapter createGitCommitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.GitUpdate <em>Git Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.GitUpdate
	 * @generated
	 */
	public Adapter createGitUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck <em>Service Check</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ServiceCheck
	 * @generated
	 */
	public Adapter createServiceCheckAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop <em>Remote Desktop</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.RemoteDesktop
	 * @generated
	 */
	public Adapter createRemoteDesktopAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Java <em>Java</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Java
	 * @generated
	 */
	public Adapter createJavaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe <em>Exe</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Exe
	 * @generated
	 */
	public Adapter createExeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS <em>SSMS</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SSMS
	 * @generated
	 */
	public Adapter createSSMSAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard <em>Clipboard</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Clipboard
	 * @generated
	 */
	public Adapter createClipboardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator <em>String Separator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator
	 * @generated
	 */
	public Adapter createStringSeparatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter <em>String Splitter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSplitter
	 * @generated
	 */
	public Adapter createStringSplitterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer <em>String Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringReplacer
	 * @generated
	 */
	public Adapter createStringReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToXls <em>String To Xls</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToXls
	 * @generated
	 */
	public Adapter createStringToXlsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile <em>String To File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToFile
	 * @generated
	 */
	public Adapter createStringToFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.QuestionDialog <em>Question Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.QuestionDialog
	 * @generated
	 */
	public Adapter createQuestionDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InfoDialog <em>Info Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InfoDialog
	 * @generated
	 */
	public Adapter createInfoDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.MessageDialog <em>Message Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.MessageDialog
	 * @generated
	 */
	public Adapter createMessageDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.SelectionDialog <em>Selection Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.SelectionDialog
	 * @generated
	 */
	public Adapter createSelectionDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.FilteredDialog <em>Filtered Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.FilteredDialog
	 * @generated
	 */
	public Adapter createFilteredDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Email <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Email
	 * @generated
	 */
	public Adapter createEmailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser <em>Csv Table Parser</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.CsvTableParser
	 * @generated
	 */
	public Adapter createCsvTableParserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart <em>Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Chart
	 * @generated
	 */
	public Adapter createChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Point <em>Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Point
	 * @generated
	 */
	public Adapter createPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.LineChart <em>Line Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.LineChart
	 * @generated
	 */
	public Adapter createLineChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.BarChart <em>Bar Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.BarChart
	 * @generated
	 */
	public Adapter createBarChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ScatterChart <em>Scatter Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ScatterChart
	 * @generated
	 */
	public Adapter createScatterChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.PieChart <em>Pie Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.PieChart
	 * @generated
	 */
	public Adapter createPieChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList <em>String To List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.StringToList
	 * @generated
	 */
	public Adapter createStringToListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter <em>Sorter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter
	 * @generated
	 */
	public Adapter createSorterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.List
	 * @generated
	 */
	public Adapter createListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Item <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Item
	 * @generated
	 */
	public Adapter createItemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement <em>Replacement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacement
	 * @generated
	 */
	public Adapter createReplacementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer <em>Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Replacer
	 * @generated
	 */
	public Adapter createReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer <em>Option Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.OptionReplacer
	 * @generated
	 */
	public Adapter createOptionReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Option <em>Option</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Option
	 * @generated
	 */
	public Adapter createOptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer <em>Input Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputReplacer
	 * @generated
	 */
	public Adapter createInputReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer <em>Timestamp Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.TimestampReplacer
	 * @generated
	 */
	public Adapter createTimestampReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog <em>Input Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog
	 * @generated
	 */
	public Adapter createInputDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.TextControl <em>Text Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.TextControl
	 * @generated
	 */
	public Adapter createTextControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl <em>Date Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.DateControl
	 * @generated
	 */
	public Adapter createDateControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl <em>List Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ListControl
	 * @generated
	 */
	public Adapter createListControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl <em>Combo Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboControl
	 * @generated
	 */
	public Adapter createComboControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem <em>Combo Item</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.ComboItem
	 * @generated
	 */
	public Adapter createComboItemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control <em>Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.Control
	 * @generated
	 */
	public Adapter createControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //WorkflowAdapterFactory
