/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mkdir</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getPath <em>Path</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getNames <em>Names</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getMkdir()
 * @model
 * @generated
 */
public interface Mkdir extends Operation {
	/**
	 * Returns the value of the '<em><b>Path</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Path</em>' containment reference.
	 * @see #setPath(Path)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getMkdir_Path()
	 * @model containment="true"
	 * @generated
	 */
	Path getPath();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Mkdir#getPath <em>Path</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Path</em>' containment reference.
	 * @see #getPath()
	 * @generated
	 */
	void setPath(Path value);

	/**
	 * Returns the value of the '<em><b>Names</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.NamedElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Names</em>' containment reference list.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getMkdir_Names()
	 * @model containment="true"
	 * @generated
	 */
	EList<NamedElement> getNames();

} // Mkdir
