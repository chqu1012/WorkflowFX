/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sorter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter#isIsAsc <em>Is Asc</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getSorter()
 * @model
 * @generated
 */
public interface Sorter extends EObject {
	/**
	 * Returns the value of the '<em><b>Is Asc</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Asc</em>' attribute.
	 * @see #setIsAsc(boolean)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getSorter_IsAsc()
	 * @model default="true" unique="false"
	 * @generated
	 */
	boolean isIsAsc();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Sorter#isIsAsc <em>Is Asc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Asc</em>' attribute.
	 * @see #isIsAsc()
	 * @generated
	 */
	void setIsAsc(boolean value);

} // Sorter
