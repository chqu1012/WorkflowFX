/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.impl;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.Java;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JavaImpl extends CopyImpl implements Java {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.JAVA;
	}

} //JavaImpl
