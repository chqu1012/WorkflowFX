/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow.provider;

import de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowFactory;
import de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITableItemLabelProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class InputDialogItemProvider extends ItemProviderAdapter
		implements IEditingDomainItemProvider, IStructuredItemContentProvider, ITreeItemContentProvider,
		IItemLabelProvider, IItemPropertySource, ITableItemLabelProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputDialogItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addTitlePropertyDescriptor(object);
			addDescriptionPropertyDescriptor(object);
			addHeightPropertyDescriptor(object);
			addWidthPropertyDescriptor(object);
			addContentPropertyDescriptor(object);
			addUseTemplatePropertyDescriptor(object);
			addTemplateNamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Title feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTitlePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_title_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_title_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__TITLE, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Description feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDescriptionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_description_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_description_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__DESCRIPTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Height feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addHeightPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_height_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_height_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__HEIGHT, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Width feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWidthPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_width_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_width_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__WIDTH, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Content feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addContentPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_content_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_content_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__CONTENT, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Use Template feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addUseTemplatePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_useTemplate_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_useTemplate_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__USE_TEMPLATE, true, false, false,
						ItemPropertyDescriptor.BOOLEAN_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Template Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTemplateNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_InputDialog_templateName_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_InputDialog_templateName_feature",
								"_UI_InputDialog_type"),
						WorkflowPackage.Literals.INPUT_DIALOG__TEMPLATE_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(WorkflowPackage.Literals.INPUT_DIALOG__CONTROLS);
			childrenFeatures.add(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns InputDialog.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/InputDialog"));
	}

	/**
	 * This returns <code>getImage(object)</code> for the column index <code>0</code> or <code>super.getImage(object)</code> otherwise.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getText(Object)
	 * @see #getColumnText(Object, int)
	 * @generated
	 */
	@Override
	public Object getColumnImage(Object object, int columnIndex) {
		// TODO: implement this method to return appropriate information for each column.
		// Ensure that you remove @generated or mark it @generated NOT
		return columnIndex == 0 ? getImage(object) : super.getImage(object);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((InputDialog) object).getTemplateName();
		return label == null || label.length() == 0 ? getString("_UI_InputDialog_type")
				: getString("_UI_InputDialog_type") + " " + label;
	}

	/**
	 * This returns <code>getText(object)</code> for the column index <code>0</code> or <code>super.getText(object)</code> otherwise.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage(Object)
	 * @see #getColumnImage(Object, int)
	 * @generated
	 */
	@Override
	public String getColumnText(Object object, int columnIndex) {
		// TODO: implement this method to return appropriate information for each column.
		// Ensure that you remove @generated or mark it @generated NOT
		return columnIndex == 0 ? getText(object) : super.getText(object);
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(InputDialog.class)) {
		case WorkflowPackage.INPUT_DIALOG__TITLE:
		case WorkflowPackage.INPUT_DIALOG__DESCRIPTION:
		case WorkflowPackage.INPUT_DIALOG__HEIGHT:
		case WorkflowPackage.INPUT_DIALOG__WIDTH:
		case WorkflowPackage.INPUT_DIALOG__CONTENT:
		case WorkflowPackage.INPUT_DIALOG__USE_TEMPLATE:
		case WorkflowPackage.INPUT_DIALOG__TEMPLATE_NAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case WorkflowPackage.INPUT_DIALOG__CONTROLS:
		case WorkflowPackage.INPUT_DIALOG__OPERATIONS:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__CONTROLS,
				WorkflowFactory.eINSTANCE.createTextControl()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__CONTROLS,
				WorkflowFactory.eINSTANCE.createDateControl()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__CONTROLS,
				WorkflowFactory.eINSTANCE.createListControl()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__CONTROLS,
				WorkflowFactory.eINSTANCE.createComboControl()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createMkdir()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createCopy()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createZip()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createMove()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createRename()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createDelete()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createSvnCommit()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createSvnUpdate()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createGitCommit()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createGitUpdate()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createServiceCheck()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createRemoteDesktop()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createJava()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createExe()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createSSMS()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createClipboard()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createStringSeparator()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createStringSplitter()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createStringReplacer()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createStringToXls()));

		newChildDescriptors.add(createChildParameter(WorkflowPackage.Literals.INPUT_DIALOG__OPERATIONS,
				WorkflowFactory.eINSTANCE.createStringToFile()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return WorkflowEditPlugin.INSTANCE;
	}

}
