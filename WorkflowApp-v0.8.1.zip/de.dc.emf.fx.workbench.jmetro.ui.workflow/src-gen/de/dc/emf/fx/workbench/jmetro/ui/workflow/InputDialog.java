/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTitle <em>Title</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getDescription <em>Description</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getHeight <em>Height</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getWidth <em>Width</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getContent <em>Content</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#isUseTemplate <em>Use Template</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTemplateName <em>Template Name</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getControls <em>Controls</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getOperations <em>Operations</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog()
 * @model
 * @generated
 */
public interface InputDialog extends EObject {
	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Title()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Description()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Height</b></em>' attribute.
	 * The default value is <code>"400"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Height</em>' attribute.
	 * @see #setHeight(int)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Height()
	 * @model default="400" unique="false"
	 * @generated
	 */
	int getHeight();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getHeight <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Height</em>' attribute.
	 * @see #getHeight()
	 * @generated
	 */
	void setHeight(int value);

	/**
	 * Returns the value of the '<em><b>Width</b></em>' attribute.
	 * The default value is <code>"450"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Width</em>' attribute.
	 * @see #setWidth(int)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Width()
	 * @model default="450" unique="false"
	 * @generated
	 */
	int getWidth();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getWidth <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Width</em>' attribute.
	 * @see #getWidth()
	 * @generated
	 */
	void setWidth(int value);

	/**
	 * Returns the value of the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' attribute.
	 * @see #setContent(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Content()
	 * @model unique="false"
	 * @generated
	 */
	String getContent();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getContent <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' attribute.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(String value);

	/**
	 * Returns the value of the '<em><b>Use Template</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Use Template</em>' attribute.
	 * @see #setUseTemplate(boolean)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_UseTemplate()
	 * @model unique="false"
	 * @generated
	 */
	boolean isUseTemplate();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#isUseTemplate <em>Use Template</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Use Template</em>' attribute.
	 * @see #isUseTemplate()
	 * @generated
	 */
	void setUseTemplate(boolean value);

	/**
	 * Returns the value of the '<em><b>Template Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Template Name</em>' attribute.
	 * @see #setTemplateName(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_TemplateName()
	 * @model unique="false"
	 * @generated
	 */
	String getTemplateName();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.InputDialog#getTemplateName <em>Template Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Template Name</em>' attribute.
	 * @see #getTemplateName()
	 * @generated
	 */
	void setTemplateName(String value);

	/**
	 * Returns the value of the '<em><b>Controls</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Control}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controls</em>' containment reference list.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Controls()
	 * @model containment="true"
	 * @generated
	 */
	EList<Control> getControls();

	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInputDialog_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

} // InputDialog
