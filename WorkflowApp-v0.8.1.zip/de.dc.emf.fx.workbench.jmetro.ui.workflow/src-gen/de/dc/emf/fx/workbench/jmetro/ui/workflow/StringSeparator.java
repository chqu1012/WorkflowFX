/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String Separator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator#getLineSeparator <em>Line Separator</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getStringSeparator()
 * @model
 * @generated
 */
public interface StringSeparator extends Clipboard {
	/**
	 * Returns the value of the '<em><b>Line Separator</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Line Separator</em>' attribute.
	 * @see #setLineSeparator(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getStringSeparator_LineSeparator()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getLineSeparator();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.StringSeparator#getLineSeparator <em>Line Separator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Line Separator</em>' attribute.
	 * @see #getLineSeparator()
	 * @generated
	 */
	void setLineSeparator(String value);

} // StringSeparator
