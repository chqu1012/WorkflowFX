/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DB Table View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getDatabase <em>Database</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getTable <em>Table</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getQueries <em>Queries</em>}</li>
 *   <li>{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getConsole <em>Console</em>}</li>
 * </ul>
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBTableView()
 * @model
 * @generated
 */
public interface DBTableView extends View {
	/**
	 * Returns the value of the '<em><b>Database</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Database</em>' containment reference.
	 * @see #setDatabase(DBConfig)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBTableView_Database()
	 * @model containment="true"
	 * @generated
	 */
	DBConfig getDatabase();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getDatabase <em>Database</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Database</em>' containment reference.
	 * @see #getDatabase()
	 * @generated
	 */
	void setDatabase(DBConfig value);

	/**
	 * Returns the value of the '<em><b>Table</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Table</em>' attribute.
	 * @see #setTable(String)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBTableView_Table()
	 * @model unique="false"
	 * @generated
	 */
	String getTable();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getTable <em>Table</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Table</em>' attribute.
	 * @see #getTable()
	 * @generated
	 */
	void setTable(String value);

	/**
	 * Returns the value of the '<em><b>Queries</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.emf.fx.workbench.jmetro.ui.workflow.Query}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Queries</em>' containment reference list.
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBTableView_Queries()
	 * @model containment="true"
	 * @generated
	 */
	EList<Query> getQueries();

	/**
	 * Returns the value of the '<em><b>Console</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Console</em>' containment reference.
	 * @see #setConsole(DBConsole)
	 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getDBTableView_Console()
	 * @model containment="true"
	 * @generated
	 */
	DBConsole getConsole();

	/**
	 * Sets the value of the '{@link de.dc.emf.fx.workbench.jmetro.ui.workflow.DBTableView#getConsole <em>Console</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Console</em>' containment reference.
	 * @see #getConsole()
	 * @generated
	 */
	void setConsole(DBConsole value);

} // DBTableView
