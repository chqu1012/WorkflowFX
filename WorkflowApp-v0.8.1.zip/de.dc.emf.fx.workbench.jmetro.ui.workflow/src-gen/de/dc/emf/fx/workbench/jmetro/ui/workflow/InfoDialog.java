/**
 */
package de.dc.emf.fx.workbench.jmetro.ui.workflow;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Info Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.fx.workbench.jmetro.ui.workflow.WorkflowPackage#getInfoDialog()
 * @model
 * @generated
 */
public interface InfoDialog extends EObject {
} // InfoDialog
